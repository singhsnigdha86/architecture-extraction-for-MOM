/**
 * This package contains entites relevant to multiple models.
 */
package org.palladiosimulator.generator.fluent.shared.structure;
