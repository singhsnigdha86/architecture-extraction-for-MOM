package org.palladiosimulator.somox.analyzer.rules.spring;

import java.nio.file.Path;
import java.util.List;
import java.util.Set;
import java.util.function.Consumer;
import org.eclipse.emf.common.util.EList;
import org.emftext.language.java.classifiers.Interface;
import org.emftext.language.java.containers.impl.CompilationUnitImpl;
import org.emftext.language.java.members.Constructor;
import org.emftext.language.java.members.Field;
import org.emftext.language.java.members.Method;
import org.emftext.language.java.parameters.Parameter;
import org.palladiosimulator.somox.analyzer.rules.blackboard.RuleEngineBlackboard;
import org.palladiosimulator.somox.analyzer.rules.engine.IRule;
import org.palladiosimulator.somox.analyzer.rules.engine.PCMDetectorSimple;
import org.palladiosimulator.somox.analyzer.rules.engine.RuleHelper;

@SuppressWarnings("all")
public class SpringRules extends IRule {
  public SpringRules(final RuleEngineBlackboard blackboard) {
    super(blackboard);
  }

  @Override
  public boolean processRules(final Path path) {
    final Set<CompilationUnitImpl> unitImpls = this.blackboard.getCompilationUnitAt(path);
    boolean containedSuccessful = false;
    for (final CompilationUnitImpl unitImpl : unitImpls) {
      containedSuccessful = (this.processRuleForCompUnit(unitImpl) || containedSuccessful);
    }
    return containedSuccessful;
  }

  public boolean processRuleForCompUnit(final CompilationUnitImpl unitImpl) {
    final PCMDetectorSimple pcmDetector = this.blackboard.getPCMDetector();
    if ((unitImpl == null)) {
      return false;
    }
    final boolean isAbstract = RuleHelper.isAbstraction(unitImpl);
    final boolean isComponent = ((!isAbstract) && RuleHelper.isUnitAnnotatedWithName(unitImpl, "Component", "Service", "Controller", "RestController", "RequestMapping", "ControllerAdvice"));
    if (isComponent) {
      pcmDetector.detectComponent(unitImpl);
    }
    if ((RuleHelper.isUnitAnnotatedWithName(unitImpl, "FeignClient", "Repository") || (RuleHelper.isUnitNamedWith(unitImpl, "Repository") && isAbstract))) {
      pcmDetector.detectComponent(unitImpl);
      pcmDetector.detectOperationInterface(unitImpl);
      final Consumer<Method> _function = (Method m) -> {
        pcmDetector.detectProvidedInterface(unitImpl, m);
      };
      RuleHelper.getMethods(unitImpl).forEach(_function);
    }
    List<Interface> inFs = RuleHelper.getAllInterfaces(unitImpl);
    int _size = inFs.size();
    final boolean isImplementingOne = (_size == 1);
    if ((isComponent && isImplementingOne)) {
      Interface firstIn = inFs.get(0);
      pcmDetector.detectOperationInterface(firstIn);
      List<Method> _methods = RuleHelper.getMethods(firstIn);
      for (final Method m : _methods) {
        pcmDetector.detectProvidedInterface(unitImpl, firstIn, m);
      }
    }
    if ((isComponent && (!isImplementingOne))) {
      List<Method> _methods_1 = RuleHelper.getMethods(unitImpl);
      for (final Method m_1 : _methods_1) {
        {
          final boolean annoWithName = RuleHelper.isMethodAnnotatedWithName(m_1, "RequestMapping", "GetMapping", "PutMapping", "PostMapping", "DeleteMapping", "PatchMapping");
          if ((annoWithName || ((!annoWithName) && m_1.isPublic()))) {
            pcmDetector.detectProvidedInterface(unitImpl, m_1);
          }
          pcmDetector.detectOperationInterface(unitImpl);
        }
      }
    }
    if (isComponent) {
      List<Field> _fields = RuleHelper.getFields(unitImpl);
      for (final Field f : _fields) {
        {
          final boolean annotated = RuleHelper.isFieldAnnotatedWithName(f, "Autowired");
          if (annotated) {
            pcmDetector.detectRequiredInterface(unitImpl, f);
          }
          final boolean abstr = RuleHelper.isFieldAbstract(f);
          final boolean modi = RuleHelper.isFieldModifiedExactlyWith(f, "private", "final");
          if ((((!annotated) && abstr) && modi)) {
            pcmDetector.detectRequiredInterface(unitImpl, f);
          }
          if ((((!abstr) && modi) && RuleHelper.isClassOfFieldAnnotatedWithName(f, "Component", "Service", "Controller", "RestController", "RequestMapping", "ControllerAdvice"))) {
            pcmDetector.detectRequiredInterface(unitImpl, f);
          }
        }
      }
      List<Method> _methods_2 = RuleHelper.getMethods(unitImpl);
      for (final Method m_2 : _methods_2) {
        boolean _isMethodAnnotatedWithName = RuleHelper.isMethodAnnotatedWithName(m_2, "Autowired");
        if (_isMethodAnnotatedWithName) {
          EList<Parameter> _parameters = m_2.getParameters();
          for (final Parameter p : _parameters) {
            {
              final boolean isParaAbstract = RuleHelper.isParameterAbstract(p);
              if (isParaAbstract) {
                pcmDetector.detectRequiredInterface(unitImpl, p);
              }
              if (((!isParaAbstract) && RuleHelper.isParameterAClassAnnotatedWith(p, "Component", "Service", "Controller", "RestController", "RequestMapping", "ControllerAdvice"))) {
                pcmDetector.detectRequiredInterface(unitImpl, p);
              }
            }
          }
        }
      }
      final Consumer<Constructor> _function_1 = (Constructor constructor) -> {
        boolean _isConstructorAnnotatedWithName = RuleHelper.isConstructorAnnotatedWithName(constructor, "Autowired");
        if (_isConstructorAnnotatedWithName) {
          final Consumer<Parameter> _function_2 = (Parameter para) -> {
            if ((RuleHelper.isParameterAbstract(para) || RuleHelper.isParameterAClassAnnotatedWith(para, "Component", "Service", "Controller", "RestController", "RequestMapping", "ControllerAdvice"))) {
              pcmDetector.detectRequiredInterface(unitImpl, para);
            }
            if (((!RuleHelper.isParameterAbstract(para)) && RuleHelper.isParameterAnnotatedWith(para, "LoadBalanced"))) {
              pcmDetector.detectRequiredInterface(unitImpl, para);
            }
          };
          constructor.getParameters().forEach(_function_2);
        }
      };
      RuleHelper.getConstructors(unitImpl).forEach(_function_1);
    }
    return true;
  }
}
