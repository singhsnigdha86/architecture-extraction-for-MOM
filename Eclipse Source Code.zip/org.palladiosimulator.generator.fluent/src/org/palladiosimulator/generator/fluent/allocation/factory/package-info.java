/**
 * This package contains the factory to create an
 * {@link org.palladiosimulator.pcm.allocation.Allocation Allocation} model.
 *
 * @see org.palladiosimulator.generator.fluent.allocation.factory.FluentAllocationFactory
 */
package org.palladiosimulator.generator.fluent.allocation.factory;
