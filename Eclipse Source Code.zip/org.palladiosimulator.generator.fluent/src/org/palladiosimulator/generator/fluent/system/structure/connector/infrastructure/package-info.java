/**
 * This package contains the creators for connectors concerning infrastructure.
 */
package org.palladiosimulator.generator.fluent.system.structure.connector.infrastructure;
