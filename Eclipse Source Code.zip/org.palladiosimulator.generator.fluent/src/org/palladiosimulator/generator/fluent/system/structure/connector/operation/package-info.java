/**
 * This package contains the creators for connectors concerning operations.
 */
package org.palladiosimulator.generator.fluent.system.structure.connector.operation;
