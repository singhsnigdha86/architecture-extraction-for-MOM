package org.palladiosimulator.generator.fluent.allocation.api;

/**
 * TODO
 */
public interface IAllocation extends IAllocationAddition {
    /**
     * Defines the name of the org.palladiosimulator.generator.fluent.allocation
     *
     * @param name
     * @return this org.palladiosimulator.generator.fluent.allocation
     */
    IAllocation withName(String name);
}
