/**
 * This package contains the interfaces used to add entities to a
 * {@link org.palladiosimulator.pcm.system.System System} model.
 */
package org.palladiosimulator.generator.fluent.system.api;
