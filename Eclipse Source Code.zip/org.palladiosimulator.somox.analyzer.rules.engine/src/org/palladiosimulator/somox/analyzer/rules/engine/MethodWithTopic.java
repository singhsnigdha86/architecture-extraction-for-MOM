package org.palladiosimulator.somox.analyzer.rules.engine;

import org.emftext.language.java.members.Method;
import org.emftext.language.java.references.MethodCall;

/**
 * This class encapsulate the method that sends/receives to/from topic, the
 * topic, for senders the call that sends, event type and the role of the
 * pcm-Component. it can considered as data object.
 */
public class MethodWithTopic {

	private final Method method;
	private final String topic;
	private final MethodCall call;
	private String eventType;
	private String role;

	public MethodWithTopic(String topic, Method method, MethodCall call) {
		this.topic = topic;
		this.method = method;
		this.call = call;

	}

	public String getTopic() {
		return topic;
	}

	public Method getMethod() {
		return method;
	}

	public MethodCall getCall() {
		return call;
	}

	public void setEventType(String eventType) {
		this.eventType = eventType;
	}

	public void setRole(String role) {
		this.role = role;
	}

	public String getRole() {
		return role;
	}

	public String getEventType() {
		return eventType;
	}

	@Override
	public String toString() {
		return topic + ":" + method.getName();
	}

}
