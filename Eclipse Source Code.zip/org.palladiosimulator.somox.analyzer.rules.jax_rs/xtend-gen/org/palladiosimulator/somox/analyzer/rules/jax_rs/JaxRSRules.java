package org.palladiosimulator.somox.analyzer.rules.jax_rs;

import java.nio.file.Path;
import java.util.Set;
import java.util.function.Consumer;
import org.emftext.language.java.classifiers.Interface;
import org.emftext.language.java.containers.impl.CompilationUnitImpl;
import org.emftext.language.java.members.Field;
import org.emftext.language.java.members.Method;
import org.palladiosimulator.somox.analyzer.rules.blackboard.RuleEngineBlackboard;
import org.palladiosimulator.somox.analyzer.rules.engine.IRule;
import org.palladiosimulator.somox.analyzer.rules.engine.PCMDetectorSimple;
import org.palladiosimulator.somox.analyzer.rules.engine.RuleHelper;

@SuppressWarnings("all")
public class JaxRSRules extends IRule {
  public JaxRSRules(final RuleEngineBlackboard blackboard) {
    super(blackboard);
  }

  @Override
  public boolean processRules(final Path path) {
    final Set<CompilationUnitImpl> unitImpls = this.blackboard.getCompilationUnitAt(path);
    boolean containedSuccessful = false;
    for (final CompilationUnitImpl unitImpl : unitImpls) {
      containedSuccessful = (this.processRuleForCompUnit(unitImpl) || containedSuccessful);
    }
    return containedSuccessful;
  }

  public boolean processRuleForCompUnit(final CompilationUnitImpl unitImpl) {
    final PCMDetectorSimple pcmDetector = this.blackboard.getPCMDetector();
    final boolean isConverter = RuleHelper.isUnitAnnotatedWithName(unitImpl, "Converter");
    if (isConverter) {
      this.detectDefault(unitImpl);
      return true;
    }
    final boolean isUnitController = RuleHelper.isUnitAnnotatedWithName(unitImpl, "Path");
    if (isUnitController) {
      pcmDetector.detectComponent(unitImpl);
      pcmDetector.detectOperationInterface(unitImpl);
      final Consumer<Method> _function = (Method m) -> {
        boolean _isMethodAnnotatedWithName = RuleHelper.isMethodAnnotatedWithName(m, "DELETE", "GET", "HEAD", "PUT", "POST", "OPTIONS");
        if (_isMethodAnnotatedWithName) {
          pcmDetector.detectProvidedInterface(unitImpl, m);
        }
      };
      RuleHelper.getMethods(unitImpl).forEach(_function);
      final Consumer<Field> _function_1 = (Field f) -> {
        boolean _isFieldAbstract = RuleHelper.isFieldAbstract(f);
        if (_isFieldAbstract) {
          pcmDetector.detectRequiredInterface(unitImpl, f);
        }
      };
      RuleHelper.getFields(unitImpl).forEach(_function_1);
      return true;
    }
    final boolean isWebListener = RuleHelper.isUnitAnnotatedWithName(unitImpl, "WebListener", "WebServlet");
    if (isWebListener) {
      pcmDetector.detectComponent(unitImpl);
      pcmDetector.detectOperationInterface(unitImpl);
      final Consumer<Method> _function_2 = (Method m) -> {
        if ((RuleHelper.isMethodModifiedExactlyWith(m, "public") || RuleHelper.isMethodModifiedExactlyWith(m, "protected"))) {
          pcmDetector.detectProvidedInterface(unitImpl, m);
        }
      };
      RuleHelper.getMethods(unitImpl).forEach(_function_2);
      final Consumer<Field> _function_3 = (Field f) -> {
        boolean _isFieldAbstract = RuleHelper.isFieldAbstract(f);
        if (_isFieldAbstract) {
          pcmDetector.detectRequiredInterface(unitImpl, f);
        }
      };
      RuleHelper.getFields(unitImpl).forEach(_function_3);
      return true;
    }
    final boolean isUnitImpl = RuleHelper.isClassImplementing(unitImpl);
    if ((((isUnitImpl && (!isUnitController)) && (!isWebListener)) && (RuleHelper.getAllInterfaces(unitImpl).size() > 0))) {
      pcmDetector.detectComponent(unitImpl);
      final Interface firstIn = RuleHelper.getAllInterfaces(unitImpl).get(0);
      pcmDetector.detectOperationInterface(firstIn);
      final Consumer<Method> _function_4 = (Method m) -> {
        pcmDetector.detectProvidedInterface(unitImpl, firstIn, m);
      };
      RuleHelper.getMethods(firstIn).forEach(_function_4);
      final Consumer<Field> _function_5 = (Field f) -> {
        boolean _isFieldAbstract = RuleHelper.isFieldAbstract(f);
        if (_isFieldAbstract) {
          pcmDetector.detectRequiredInterface(unitImpl, f);
        }
      };
      RuleHelper.getFields(unitImpl).forEach(_function_5);
      return true;
    }
    final boolean classModified = RuleHelper.isClassModifiedExactlyWith(unitImpl, "public", "final");
    if (((((!isUnitImpl) && (!isUnitController)) && (!isWebListener)) && classModified)) {
      pcmDetector.detectComponent(unitImpl);
      this.detectDefault(unitImpl);
      return true;
    }
    return false;
  }

  public void detectDefault(final CompilationUnitImpl unitImpl) {
    final PCMDetectorSimple pcmDetector = this.blackboard.getPCMDetector();
    pcmDetector.detectComponent(unitImpl);
    pcmDetector.detectOperationInterface(unitImpl);
    final Consumer<Method> _function = (Method m) -> {
      pcmDetector.detectProvidedInterface(unitImpl, m);
    };
    RuleHelper.getAllPublicMethods(unitImpl).forEach(_function);
    final Consumer<Field> _function_1 = (Field f) -> {
      boolean _isFieldAbstract = RuleHelper.isFieldAbstract(f);
      if (_isFieldAbstract) {
        pcmDetector.detectRequiredInterface(unitImpl, f);
      }
    };
    RuleHelper.getFields(unitImpl).forEach(_function_1);
  }
}
