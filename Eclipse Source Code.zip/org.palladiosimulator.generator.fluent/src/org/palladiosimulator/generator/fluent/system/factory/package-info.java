/**
 * This package contains the factory to create a {@link org.palladiosimulator.pcm.system.System
 * System} model.
 *
 * @see org.palladiosimulator.generator.fluent.resourceenvironment.system.FluentSystemFactory
 */
package org.palladiosimulator.generator.fluent.system.factory;
