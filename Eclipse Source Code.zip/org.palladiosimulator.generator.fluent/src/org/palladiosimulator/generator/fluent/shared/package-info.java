/**
 * This package contains the utility functions and entities relevant to multiple models.
 */
package org.palladiosimulator.generator.fluent.shared;
