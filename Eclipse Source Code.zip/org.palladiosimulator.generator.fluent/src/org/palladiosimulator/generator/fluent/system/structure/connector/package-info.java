/**
 * This package contains the creators for
 * {@link org.palladiosimulator.pcm.core.composition.Connector Connectors}s.
 */
package org.palladiosimulator.generator.fluent.system.structure.connector;
