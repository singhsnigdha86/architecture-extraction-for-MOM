/**
 * @author Yves Kirschner
 */
package org.palladiosimulator.generator.fluent;
