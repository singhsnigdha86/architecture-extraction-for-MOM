/**
 * This package contains the creators for connectors concerning resources.
 */
package org.palladiosimulator.generator.fluent.system.structure.connector.resource;
