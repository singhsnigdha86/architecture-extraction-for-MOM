package org.palladiosimulator.generator.fluent.usagemodel.api;

/**
 * The Interface IUsageModel.
 */
public interface IUsageModel extends IUsageModelAddition {

}
