/**
 * This package contains the creators for Roles provided or required by the
 * org.palladiosimulator.generator.fluent.system.
 */
package org.palladiosimulator.generator.fluent.system.structure.role;
