package org.palladiosimulator.somox.analyzer.rules.engine;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;

import org.eclipse.emf.ecore.EObject;
import org.emftext.language.java.containers.impl.CompilationUnitImpl;
import org.emftext.language.java.expressions.Expression;
import org.emftext.language.java.members.Method;
import org.emftext.language.java.references.MethodCall;
import org.emftext.language.java.references.impl.MethodCallImpl;
import org.emftext.language.java.statements.Block;
import org.emftext.language.java.statements.Condition;
import org.emftext.language.java.statements.DoWhileLoop;
import org.emftext.language.java.statements.ForLoop;
import org.emftext.language.java.statements.Statement;
import org.emftext.language.java.statements.WhileLoop;
import org.emftext.language.java.statements.impl.ExpressionStatementImpl;
import org.emftext.language.java.statements.impl.LocalVariableStatementImpl;
import org.palladiosimulator.generator.fluent.repository.api.Repo;
import org.palladiosimulator.generator.fluent.repository.api.seff.ActionSeff;
import org.palladiosimulator.generator.fluent.repository.api.seff.Seff;
import org.palladiosimulator.generator.fluent.repository.factory.FluentRepositoryFactory;
import org.palladiosimulator.generator.fluent.repository.structure.components.BasicComponentCreator;
import org.palladiosimulator.generator.fluent.repository.structure.components.seff.BranchActionCreator;
import org.palladiosimulator.generator.fluent.repository.structure.components.seff.EmitEventActionCreator;
import org.palladiosimulator.generator.fluent.repository.structure.components.seff.StartActionCreator;
import org.palladiosimulator.generator.fluent.repository.structure.interfaces.EventGroupCreator;
import org.palladiosimulator.generator.fluent.repository.structure.interfaces.EventTypeCreator;
import org.palladiosimulator.generator.fluent.repository.structure.interfaces.OperationInterfaceCreator;
import org.palladiosimulator.pcm.repository.BasicComponent;
import org.palladiosimulator.pcm.repository.Repository;
import org.palladiosimulator.somox.analyzer.rules.blackboard.RuleEngineBlackboard;

/**
 * This class creates the pcm-Repository-model and pcm-system-model for the
 * elements identified by the mom rule
 *
 */
public class PCMInstanceCreatorMoM extends PCMInstanceCreator {

	private final static String REPO_NAME = "Software Architecture Repository";
	private final FluentRepositoryFactory create;
	private final Repo repository;
	private final RuleEngineBlackboard blackboard;
	private org.palladiosimulator.pcm.system.System system;
	private List<String> createdEventTypes;
	private List<Method> providedInterfaceSignatures;
	private Map<String, List<String>> microserviceToProvidedRoles;

	public PCMInstanceCreatorMoM(RuleEngineBlackboard blackboard) {
		super(blackboard);
		create = new FluentRepositoryFactory();

		repository = create.newRepository().withName(REPO_NAME);
		this.blackboard = blackboard;
		createdEventTypes = new ArrayList<>();
		providedInterfaceSignatures = new ArrayList<>();
		microserviceToProvidedRoles = new HashMap<>();

	}

	/**
	 * create a pcm-repository-model and pcm-system-modell from the mapping, which
	 * maps the name of the microservice to the group of components that make upd
	 * the microservice and returns th respoitory
	 * 
	 * @param mapping the mapping of the name of the microservice and it's
	 *                components
	 */
	public Repository createPCM(Map<String, List<CompilationUnitImpl>> mapping) {

		final Map<CompilationUnitImpl, List<MethodWithTopic>> senders = ((PCMDetectorMom) blackboard.getPCMDetector())
				.getSenders();
		final Map<CompilationUnitImpl, List<MethodWithTopic>> receivers = ((PCMDetectorMom) blackboard.getPCMDetector())
				.getReceivers();

		final Set<String> topics = getAllNamesOfTopics(senders);

		Map<String, List<MethodWithTopic>> microserviceSenders = connectMicroserviceWithTopic(mapping, senders, topics);
		Map<String, List<MethodWithTopic>> microserviceReceivers = connectMicroserviceWithTopic(mapping, receivers,
				topics);

		deleteSelfReceivingRoles(microserviceSenders, microserviceReceivers);

		createPCMEventGroups(topics, microserviceSenders, microserviceReceivers);

		createPCMComponents(microserviceSenders, microserviceReceivers);

		Repository repo = repository.createRepositoryNow();

		this.system = new PCMSystemModelCreator(repo, blackboard).createPCMSystemModel(microserviceSenders,
				microserviceReceivers, microserviceToProvidedRoles);

		return repo;
	}

	/**
	 * Deletes a microservice from the receiver list from a specific topic, iff the
	 * microservice is the only sender to this specific topic
	 * 
	 * @param microserviceSenders   the senders together with the relevant
	 *                              informations
	 * @param microserviceReceivers the receivers together with the relevant
	 *                              informations
	 */
	private void deleteSelfReceivingRoles(Map<String, List<MethodWithTopic>> microserviceSenders,
			Map<String, List<MethodWithTopic>> microserviceReceivers) {
		Map<String, List<String>> topicsToSender = new HashMap<>();

		for (String microservice : microserviceSenders.keySet()) {
			for (MethodWithTopic methodWithTopic : microserviceSenders.get(microservice)) {
				if (!topicsToSender.containsKey(methodWithTopic.getTopic())) {
					topicsToSender.put(methodWithTopic.getTopic(), new ArrayList<>());
				}
				if (!topicsToSender.get(methodWithTopic.getTopic()).contains(microservice)) {
					topicsToSender.get(methodWithTopic.getTopic()).add(microservice);
				}
			}
		}

		Map<String, List<MethodWithTopic>> toBeDeleted = new HashMap<>();
		for (String microservice : microserviceReceivers.keySet()) {
			for (MethodWithTopic methodWithTopic : microserviceReceivers.get(microservice)) {
				if (topicsToSender.get(methodWithTopic.getTopic()) != null
						&& topicsToSender.get(methodWithTopic.getTopic()).size() == 1
						&& topicsToSender.get(methodWithTopic.getTopic()).contains(microservice)) {

					if (!toBeDeleted.containsKey(microservice)) {
						toBeDeleted.put(microservice, new ArrayList<>());
					}
					toBeDeleted.get(microservice).add(methodWithTopic);
				}
			}
		}
		for (String microservice : microserviceReceivers.keySet()) {

			if (toBeDeleted.containsKey(microservice)) {
				microserviceReceivers.get(microservice).removeAll(toBeDeleted.get(microservice));
			}
		}

	}

	/**
	 * creates the event groups that are found in the system. the event group is
	 * here the topic the name of the event group is the nmae of the topic and each
	 * event group contains an event type with the same name of the event group
	 * 
	 * @param topics                     the topics, that are found in the system
	 * @param compositeComponentSenders  the senders that are found in the system
	 * @param compositeComponentReceiver the receivers that are found in the system
	 */
	private void createPCMEventGroups(Set<String> topics, Map<String, List<MethodWithTopic>> compositeComponentSenders,
			Map<String, List<MethodWithTopic>> compositeComponentReceiver) {
		
		for (String topic : topics) {
			EventGroupCreator eventGroup = create.newEventGroup().withName(topic.replaceAll("\\.", "_"));
			for (String sender : compositeComponentSenders.keySet()) {
				boolean isContainedInSenders = compositeComponentSenders.get(sender).stream()
						.anyMatch(method -> method.getTopic().equals(topic));
				if (isContainedInSenders) {
					MethodWithTopic sendMethod = compositeComponentSenders.get(sender).stream()
							.filter(method -> method.getTopic().equals(topic)).collect(Collectors.toList()).get(0);
					String nameOfEventType = constructNameOfEventType(sendMethod);
					if (!createdEventTypes.contains(nameOfEventType)) {

						createdEventTypes.add(nameOfEventType);
						EventTypeCreator eventTyp = create.newEventType().withName(nameOfEventType);

						eventGroup = eventGroup.withEventType(eventTyp);
					}

				}

			}
			repository.addToRepository(eventGroup);
		}

	}

	/**
	 * Creates pcm-components for the microservices. Each pcm-Components contains at
	 * least one source role or one sink role
	 * 
	 * @param microserviceSenders   the sender microservice
	 * @param microserviceReceivers the receiver microservice
	 */
	private void createPCMComponents(Map<String, List<MethodWithTopic>> microserviceSenders,
			Map<String, List<MethodWithTopic>> microserviceReceivers) {
		// build repository component
		for (final String microserviceName : microserviceSenders.keySet()) {
			List<String> createdSourceRoles = new ArrayList<>();
			List<String> createdSinkRoles = new ArrayList<>();
			BasicComponentCreator pcmComp = create.newBasicComponent().withName(microserviceName);

			if (microserviceSenders.get(microserviceName) != null) {

				for (MethodWithTopic senderTopic : microserviceSenders.get(microserviceName)) {
					createSourceRolesForComponenteCreator(senderTopic, microserviceReceivers, pcmComp, microserviceName,
							createdSourceRoles);

				}
				createOperationProvidedInterface(microserviceName, microserviceSenders.get(microserviceName),
						microserviceReceivers.get(microserviceName), pcmComp);

			}
			if (microserviceReceivers.get(microserviceName) != null) {
				for (MethodWithTopic receiverTopic : microserviceReceivers.get(microserviceName)) {
					createSinkRolesForComponenteCreator(receiverTopic, microserviceSenders, pcmComp, microserviceName,
							createdSinkRoles);
				}
			}
			BasicComponent builtComp = pcmComp.build();

			CompilationUnitImpl buildtMicroserviceUnit = ((PCMDetectorMom) blackboard.getPCMDetector())
					.getMicroservices().stream()
					.filter(microserviceUnit -> microserviceUnit.getName().equals(microserviceName))
					.collect(Collectors.toList()).get(0);

			blackboard.putRepositoryComponentLocation(builtComp, buildtMicroserviceUnit);

			repository.addToRepository(builtComp);
		}

		// build repository component iff the microservice is only receiver
		for (final String microserviceName : microserviceReceivers.keySet()) {
			List<String> createdSinkRoles = new ArrayList<>();

			if (microserviceSenders.keySet().contains(microserviceName)) {
				continue;
			} else {
				BasicComponentCreator pcmComp = create.newBasicComponent().withName(microserviceName);

				for (MethodWithTopic receiverTopic : microserviceReceivers.get(microserviceName)) {
					createSinkRolesForComponenteCreator(receiverTopic, microserviceSenders, pcmComp, microserviceName,
							createdSinkRoles);
				}
				BasicComponent builtComp = pcmComp.build();

				CompilationUnitImpl buildtMicroserviceUnit = ((PCMDetectorMom) blackboard.getPCMDetector())
						.getMicroservices().stream()
						.filter(microserviceUnit -> microserviceUnit.getName().equals(microserviceName))
						.collect(Collectors.toList()).get(0);

				blackboard.putRepositoryComponentLocation(builtComp, buildtMicroserviceUnit);
				repository.addToRepository(builtComp);

			}

		}

	}

	/**
	 * 
	 * Creates a provided interface for the microservice with the given name. if the
	 * microservice contains a method that sends without receiving any messages. the
	 * method will be identified as a system operation and the user is the only one
	 * who will fire this method.
	 * 
	 * @param microserviceName the microservice name under creation
	 * @param senderTopics     the methods, that sends in the microservice
	 * @param receiverTopics   the methods , that receives in the microservice
	 * @param pcmComp          the pcm component under creation
	 */
	private void createOperationProvidedInterface(String microserviceName, List<MethodWithTopic> senderTopics,
			List<MethodWithTopic> receiverTopics, BasicComponentCreator pcmComp) {

		String interfaceName = constructNameOfProvidedInterface(microserviceName);
		OperationInterfaceCreator operationInterface = null;
		boolean interfaceCreated = false;
		// iterate over all methods
		for (MethodWithTopic senderTopic : senderTopics) {
			boolean isSystemCall = true;
			// if the send-method is not receiver-method
			if (receiverTopics != null) {
				isSystemCall = receiverTopics.stream()
						.filter(methodWithTopic -> methodWithTopic.getMethod() == senderTopic.getMethod())
						.collect(Collectors.toList()).isEmpty();
			}
			// if the method is sender and it is not created yet
			if (isSystemCall && !providedInterfaceSignatures.contains(senderTopic.getMethod())) {
				providedInterfaceSignatures.add(senderTopic.getMethod());
				if (!interfaceCreated) {
					operationInterface = create.newOperationInterface();
					operationInterface.withName(interfaceName);
					interfaceCreated = true;
				}

				String signatureName = constructNameOfSignature(senderTopic);
				operationInterface.withOperationSignature(create.newOperationSignature().withName(signatureName));
				pcmComp.withServiceEffectSpecification(
						(createSeffOfMethod(senderTopic.getMethod().getBlock(), senderTopic, receiverTopics))
								.onSignature(create.fetchOfSignature(signatureName)));

				String providedRole = constructNameOfProvidedRole(signatureName);

				if (microserviceToProvidedRoles.containsKey(microserviceName)) {
					microserviceToProvidedRoles.get(microserviceName).add(providedRole);
				} else {
					List<String> list = new ArrayList<>();
					list.add(providedRole);
					microserviceToProvidedRoles.put(microserviceName, list);
				}

			}
		}
		if (!interfaceCreated) {
			return;
		}

		String nameOfProvidedRole = constructNameOfProvidedRole(microserviceName);
		pcmComp.provides(operationInterface, nameOfProvidedRole);

	}

	/**
	 * Creates sink role for a given pcm-component to the topic
	 * 
	 * @param receiverTopic            the topic, from which it will be received
	 * @param microserviceSenders      the senders to the given pcm-component
	 * @param pcmComp                  the pcm-component under creating
	 * @param microserviceReceiverName the name of the receiver
	 * @param createdSinkRoles         the already created sink roles for the pcm
	 *                                 component
	 */
	private void createSinkRolesForComponenteCreator(MethodWithTopic receiverTopic,
			Map<String, List<MethodWithTopic>> microserviceSenders, BasicComponentCreator pcmComp,
			String microserviceReceiverName, List<String> createdSinkRoles) {

		List<String> namesOfMicroserviceSenders = getNamesForDataInterfaces(receiverTopic.getTopic(),
				microserviceSenders);
		for (String nameOfMicroserviceSender : namesOfMicroserviceSenders) {
			constructNameOfSinkRole(receiverTopic, nameOfMicroserviceSender, microserviceReceiverName);
			if (createdSinkRoles.contains(receiverTopic.getRole())) {
				continue;
			}

			pcmComp = pcmComp.handles(create.fetchOfEventGroup(receiverTopic.getTopic().replaceAll("\\.", "_")),
					constructNameOfSinkRole(receiverTopic, nameOfMicroserviceSender, microserviceReceiverName));

			createdSinkRoles.add(receiverTopic.getRole());

			pcmComp.withServiceEffectSpecification(createSeffOfMethod(receiverTopic.getMethod().getBlock(),
					receiverTopic, microserviceSenders.get(microserviceReceiverName))
					.onSignature(create.fetchOfEventType(constructNameOfEventType(receiverTopic))));

		}
	}

	/**
	 * Creates source role for a given pcm-component to the topic
	 * 
	 * @param receiverTopic          the topic, to which the component will send
	 * @param microserviceReceivers  the receivers from the given pcm-component
	 * @param pcmComp                the pcm-component under creating
	 * @param microserviceSenderName the name of the sender
	 * @param createdSourceRoles     the already created sources roles for the pcm
	 *                               component
	 */
	private void createSourceRolesForComponenteCreator(MethodWithTopic senderTopic,
			Map<String, List<MethodWithTopic>> microserviceReceivers, BasicComponentCreator pcmComp,
			String microserviceSenderName, List<String> createdSourceRoles) {
		pcmComp = pcmComp.emits(create.fetchOfEventGroup(senderTopic.getTopic().replaceAll("\\.", "_")),
				constructNameOfSourceRole(senderTopic, microserviceSenderName));

	}

	/**
	 * Gets the Microservices from the given map that communicate with the given
	 * topic
	 * 
	 * @param topic                      the topic, that we want to know who is
	 *                                   communicating with it
	 * @param microserviceMappedToTopics the sedner or receivers
	 * @return list of the names of the microservices that communicate with the
	 *         given topic
	 */
	private List<String> getNamesForDataInterfaces(String topic,
			Map<String, List<MethodWithTopic>> microserviceMappedToTopics) {
		List<String> names = new ArrayList<>();
		for (String microservice : microserviceMappedToTopics.keySet()) {
			boolean isContained = microserviceMappedToTopics.get(microservice).stream()
					.anyMatch(method -> topic.equals(method.getTopic()));
			if (isContained) {
				names.add(microservice);
			}
		}
		return names;
	}

	/**
	 * Maps the name of the microservice to the topics and methods, that this
	 * microservcie contains and communicating with.
	 * 
	 * @param mapping            mapping of the name of the microservices and the
	 *                           units that are contained in the microservice
	 * @param sendersOrReceivers maps the units to the topics and methods, that this
	 *                           unit contains and communicating with.
	 * @param topics             list of all topics that are identified in the
	 *                           system
	 * @return mapping of the microservices and the methods and topics each
	 *         microservice communicating with or contains
	 */
	private Map<String, List<MethodWithTopic>> connectMicroserviceWithTopic(
			Map<String, List<CompilationUnitImpl>> mapping,
			Map<CompilationUnitImpl, List<MethodWithTopic>> sendersOrReceivers, Set<String> topics) {
		Map<String, List<MethodWithTopic>> compositeComponentWithTopic = new HashMap<>();
		for (String microserviceName : mapping.keySet())
			for (CompilationUnitImpl unit : mapping.get(microserviceName)) {
				if (sendersOrReceivers.get(unit) == null) {
					continue;
				}
				for (MethodWithTopic methodWithTopic : sendersOrReceivers.get(unit)) {

					if (!compositeComponentWithTopic.containsKey(microserviceName)) {
						compositeComponentWithTopic.put(microserviceName, new ArrayList<MethodWithTopic>());
					}
					boolean isContained = compositeComponentWithTopic.get(microserviceName).stream()
							.anyMatch(method -> methodWithTopic.getMethod().equals(method.getMethod())
									&& ((methodWithTopic.getCall() != null
											&& methodWithTopic.getCall().equals(method.getCall()))
											|| methodWithTopic.getCall() == method.getCall()));
					if (isContained) {
						continue;
					}
					if (methodWithTopic.getTopic().equals("ALL")) {
						topics.forEach(topic -> {
							boolean topicIsContained = compositeComponentWithTopic.get(microserviceName).stream()
									.anyMatch(method -> methodWithTopic.getTopic().equals(topic));
							if (!topicIsContained) {
								compositeComponentWithTopic.get(microserviceName).add(new MethodWithTopic(topic,
										methodWithTopic.getMethod(), methodWithTopic.getCall()));
							}
						});
					} else if (methodWithTopic.getTopic().contains(".endsWith")) {
						String name = methodWithTopic.getTopic().split(".endsWith")[1];
						String topicCondition = name.substring(name.indexOf("'") + 1);
						topicCondition = topicCondition.substring(0, topicCondition.indexOf("'"));
						final String finalTopicCondition = topicCondition;

						Set<String> topicsOfMoM = topics.stream().filter(topic -> topic.endsWith(finalTopicCondition))
								.collect(Collectors.toSet());
						topicsOfMoM.forEach(topic -> {
							boolean topicIsContained = compositeComponentWithTopic.get(microserviceName).stream()
									.anyMatch(method -> methodWithTopic.getTopic().equals(method.getTopic()));
							if (!topicIsContained) {
								compositeComponentWithTopic.get(microserviceName).add(new MethodWithTopic(topic,
										methodWithTopic.getMethod(), methodWithTopic.getCall()));
							}
						});

					} else {
						compositeComponentWithTopic.get(microserviceName).add(methodWithTopic);

					}

				}
			}
		return compositeComponentWithTopic;
	}

	/**
	 * Gets the name of all topics in the system. when there is no senders for a
	 * topic. the topic will be neglected. Therefore we consider only the senders
	 * 
	 * @param senders the senders in the system
	 * @return list of the names of all topics in the system
	 */
	private Set<String> getAllNamesOfTopics(Map<CompilationUnitImpl, List<MethodWithTopic>> senders) {
		Set<String> topics = new HashSet<>();
		for (CompilationUnitImpl unit : senders.keySet()) {
			for (MethodWithTopic methodWithTopic : senders.get(unit)) {
				if (!methodWithTopic.getTopic().contains("endsWith")) {
					topics.add(methodWithTopic.getTopic());
				}
			}
		}
		return topics;
	}

	/**
	 * Gets the created system model
	 * 
	 * @return the created system model
	 */
	public org.palladiosimulator.pcm.system.System getSystemModel() {
		return system;
	}

	/**
	 * Creates the Seff of the given block
	 * 
	 * @param block           the block, for which a seff will be created
	 * @param methodWithTopic the methodand the topic, for which the seff will be
	 *                        created
	 * @param sends           the methods and the topics to which the microservices,
	 *                        for which the seff will be created, sends
	 * @return the seff of the block
	 */
	private Seff createSeffOfMethod(Block block, MethodWithTopic methodWithTopic, List<MethodWithTopic> sends) {

		Seff seff = create.newSeff();
		StartActionCreator startAction = seff.withSeffBehaviour().withStartAction().withName(block.getName());
		ActionSeff lastAction = startAction.followedBy();

		for (EObject obj : block.eContents()) {
			createSeffElementForObject(obj, lastAction, methodWithTopic, sends);
		}
		lastAction.stopAction().createBehaviourNow();

		return seff;

	}

	/**
	 * Creates a seff element for the given object and adds it to the seff
	 * 
	 * @param obj             the object, for which the elemenet will be created
	 * @param lastAction      the last created seff element
	 * 
	 * @param methodWithTopic the methodand the topic, for which the seff will be
	 *                        created
	 * @param sends           the methods and the topics to which the microservices,
	 *                        for which the seff will be created, sends
	 */
	private void createSeffElementForObject(EObject obj, ActionSeff lastAction, MethodWithTopic methodWithTopic,
			List<MethodWithTopic> sends) {
		// method call
		if (obj instanceof LocalVariableStatementImpl || obj instanceof ExpressionStatementImpl) {
			createAction(lastAction, obj, sends, methodWithTopic);
		}
		// loop
		else if (obj instanceof ForLoop || obj instanceof WhileLoop || obj instanceof DoWhileLoop) {
			createSeffForLoop(obj, lastAction, methodWithTopic, sends);
		}
		// if
		else if (obj instanceof Condition) {
			BranchActionCreator branch = lastAction.branchAction();
			createSeffForBranch((Condition) obj, branch, methodWithTopic, sends);
			lastAction = branch.followedBy();

		}
	}

	/**
	 * Creates a seff element for if
	 * 
	 * @param condition       the if condition
	 * @param branch          the seff element to which the new created element will
	 *                        be added
	 * @param methodWithTopic the method and the topic, for which the seff will be
	 *                        created
	 * @param sends           the methods and the topics to which the microservices,
	 *                        for which the seff will be created, sends
	 */
	private void createSeffForBranch(Condition condition, BranchActionCreator branch, MethodWithTopic methodWithTopic,
			List<MethodWithTopic> sends) {
		Block ifBlock = (Block) condition.getStatement();
		String conditionAsString = RuleHelper.getVollConditionAsString(condition.getCondition());
		conditionAsString ="true";
		branch.withGuardedBranchTransition(conditionAsString,
				createSeffOfMethod((Block) ifBlock, methodWithTopic, sends), "If");
		EObject elseBlock = condition.getElseStatement();
		if (elseBlock == null) {

		} else if (elseBlock instanceof Block) {
			branch.withGuardedBranchTransition("!" + conditionAsString,
					createSeffOfMethod((Block) elseBlock, methodWithTopic, sends), "Else");
		} else if (elseBlock instanceof Condition) {
			createSeffForBranch((Condition) elseBlock, branch, methodWithTopic, sends);
		}

	}

	/**
	 * Creates a new internal Action or a new emit event action and add it to the
	 * seff. For that each direct method call will be considered
	 * 
	 * @param lastAction the last created seff element to which the new created seff
	 *                   element will be added
	 * @param obj        the element for which a new seff element will be created
	 * @param sends      the methods and the topics to which the microservices, for
	 *                   which the seff will be created, sends
	 */
	private void createAction(ActionSeff lastAction, EObject obj, List<MethodWithTopic> sends,
			MethodWithTopic methodToBeCreated) {

		for (MethodCallImpl call : ((Statement) obj).getChildrenByType(MethodCallImpl.class)) {

			boolean senderCall;
			if (sends != null) {
				senderCall = sends.stream().anyMatch(topic -> topic.getCall() != null && topic.getCall() == call);
			} else {
				senderCall = false;
			}
			if (senderCall || (methodToBeCreated.getCall() != null && methodToBeCreated.getCall() == call)) {
				MethodWithTopic methodTopic;
				if (senderCall) {
					methodTopic = sends.stream().filter(methodWithTopic -> methodWithTopic.getCall() == call)
							.collect(Collectors.toList()).get(0);
				} else {
					methodTopic = methodToBeCreated;
				}
				addEmitEventActionCreatorForCall(call, lastAction, methodTopic);

			} else {
				addInternalActionCreatorForCall(call, lastAction);
			}

		}
	}

	/**
	 * Creates a new seff element for loop and adds it to the seff
	 * 
	 * @param obj             the object for which the seff element will be created
	 * @param lastAction      the last created seff element to which the new created
	 *                        seff element will be added
	 * @param methodWithTopic the method and the topic, for which the seff will be
	 *                        created
	 * @param sends           the methods and the topics to which the microservices,
	 *                        for which the seff will be created, sends
	 */
	private void createSeffForLoop(EObject obj, ActionSeff lastAction, MethodWithTopic methodWithTopic,
			List<MethodWithTopic> sends) {

		List<EObject> blocksOfFor = obj.eContents().stream().filter(eObject -> eObject instanceof Block)
				.collect(Collectors.toList());

		List<EObject> expList = obj.eContents().stream().filter(object -> object instanceof Expression)
				.collect(Collectors.toList());

		String numberOfIterations = "";

		if (!expList.isEmpty()) {
			Expression exp = (Expression) expList.get(0);
			numberOfIterations = RuleHelper.getVollConditionAsString(exp);
		}
		numberOfIterations ="100";

		for (EObject forBlock : blocksOfFor) {

			lastAction = lastAction.loopAction()
					.withLoopBody(createSeffOfMethod((Block) forBlock, methodWithTopic, sends)).withName("Loop")
					.withIterationCount(numberOfIterations).followedBy();

		}
	}

	/**
	 * creates a name for the event type
	 * 
	 * @param method the method and topic for which the event type will be created
	 * @return the name of the event type for the method and the topic
	 */
	public static String constructNameOfEventType(MethodWithTopic method) {
		return method.getTopic().replaceAll("\\.", "_") + "_EventType";
	}

	/**
	 * creates a name for the source role for a given name for the sender and agiven
	 * name for the receiver and the method and the topic
	 * 
	 * @param methodWithTopic the method and the topic, for which the source role
	 *                        will be created
	 * @param sender          the name of the sender
	 * @return the created name of the source role
	 */
	public static String constructNameOfSourceRole(MethodWithTopic methodWithTopic, String sender) {
		String eventType = constructNameOfEventType(methodWithTopic);
		String role = "dataSource_" + methodWithTopic.getMethod().getName() + "_"
				+ RuleHelper.getMethodCallAsString(methodWithTopic.getCall()).replaceAll("\\.", "_") + " at "
						+ methodWithTopic.getMethod().getContainingCompilationUnit().getName();

		methodWithTopic.setEventType(eventType);
		methodWithTopic.setRole(role);
		return role;
	}

	/**
	 * creates a name for the sink role for a given name for the sender and a given
	 * name for the receiver and the method and the topic
	 * 
	 * @param methodWithTopic the method and the topic, for which the sink role will
	 *                        be created
	 * @param sender          the name of the sender
	 * @param receiver        the name of the receiver
	 * @return the created name of the sink role
	 */
	public static String constructNameOfSinkRole(MethodWithTopic methodWithTopic, String sender, String receiver) {
		String eventType = constructNameOfEventType(methodWithTopic);
		String role = "dataSink_" + methodWithTopic.getTopic() + " through " + methodWithTopic.getMethod().getName();

		methodWithTopic.setEventType(eventType);
		methodWithTopic.setRole(role);

		return role;
	}

	/**
	 * creates a name for the provided operation interface for a microservice
	 * 
	 * @param nameOfMicrservice the name of the microservice, for which the the
	 *                          interface will be created
	 * @return the name of the provided interface
	 */
	public static String constructNameOfProvidedInterface(String nameOfMicrservice) {
		return nameOfMicrservice + "_interface";
	}

	/**
	 * creates a name for a method in the operation interface
	 * 
	 * @param methodWithTopic the Method for which the signature will be created
	 * @return the name of the method
	 */
	public static String constructNameOfSignature(MethodWithTopic methodWithTopic) {
		return methodWithTopic.getMethod().getName() + " at "
				+ methodWithTopic.getMethod().getContainingCompilationUnit().getName();
	}

	/**
	 * creates a name for the provided role of a microservice
	 * 
	 * @param signature the signature of the method that the microservice provides
	 * @return the name of the provided role of the signature
	 */
	public static String constructNameOfProvidedRole(String signature) {
		return "provide_" + signature;
	}

	/**
	 * creates an internalAction for the given call and adds it to the seff
	 * 
	 * @param call       the call for which the internalAction will be created
	 * @param lastAction the last created Element in seff to which the internal
	 *                   action will be added
	 */
	private void addInternalActionCreatorForCall(MethodCall call, ActionSeff lastAction) {
		String nameOfInternalAction = RuleHelper.getMethodCallAsString(call);
		lastAction = lastAction.internalAction().withName(nameOfInternalAction).followedBy();

	}

	/**
	 * creates an emit event action for the given call and adds it to the seff
	 * 
	 * @param call       the call for which the emit event action will be created
	 * @param lastAction the last created Element in seff to which the emit event
	 *                   action will be added
	 * @param sends      the methods and the topics to which the microservices, for
	 *                   which the seff will be created, sends
	 */
	private void addEmitEventActionCreatorForCall(MethodCall call, ActionSeff lastAction, MethodWithTopic methodTopic) {

		EmitEventActionCreator emitAction = lastAction.emitEventAction();
		String nameOfEmitEventAction = RuleHelper.getMethodCallAsString(call);

		emitAction = emitAction.withName(nameOfEmitEventAction);
		emitAction = emitAction.withEventType(create.fetchOfEventType(methodTopic.getEventType()));
		emitAction = emitAction.withSourceRole(create.fetchOfSourceRole(methodTopic.getRole()));
		lastAction = emitAction.followedBy();
	}

}
