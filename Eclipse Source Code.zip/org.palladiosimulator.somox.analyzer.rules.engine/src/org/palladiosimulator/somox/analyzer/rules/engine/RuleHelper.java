package org.palladiosimulator.somox.analyzer.rules.engine;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import org.eclipse.emf.common.util.EList;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.emf.ecore.EcorePackage;
import org.emftext.language.java.annotations.AnnotationAttributeSetting;
import org.emftext.language.java.annotations.AnnotationInstance;
import org.emftext.language.java.annotations.AnnotationValue;
import org.emftext.language.java.classifiers.Class;
import org.emftext.language.java.classifiers.Classifier;
import org.emftext.language.java.classifiers.ClassifiersPackage;
import org.emftext.language.java.classifiers.ConcreteClassifier;
import org.emftext.language.java.classifiers.Enumeration;
import org.emftext.language.java.classifiers.Interface;
import org.emftext.language.java.classifiers.impl.ClassImpl;
import org.emftext.language.java.commons.NamedElement;
import org.emftext.language.java.containers.impl.CompilationUnitImpl;
import org.emftext.language.java.expressions.Expression;
import org.emftext.language.java.expressions.NestedExpression;
import org.emftext.language.java.expressions.impl.ConditionalAndExpressionImpl;
import org.emftext.language.java.expressions.impl.ConditionalOrExpressionImpl;
import org.emftext.language.java.instantiations.NewConstructorCall;
import org.emftext.language.java.literals.BooleanLiteral;
import org.emftext.language.java.literals.CharacterLiteral;
import org.emftext.language.java.literals.DecimalDoubleLiteral;
import org.emftext.language.java.literals.DecimalFloatLiteral;
import org.emftext.language.java.literals.DoubleLiteral;
import org.emftext.language.java.literals.FloatLiteral;
import org.emftext.language.java.literals.Literal;
import org.emftext.language.java.literals.LongLiteral;
import org.emftext.language.java.literals.NullLiteral;
import org.emftext.language.java.literals.impl.DecimalIntegerLiteralImpl;
import org.emftext.language.java.literals.impl.DecimalLongLiteralImpl;
import org.emftext.language.java.members.Constructor;
import org.emftext.language.java.members.Field;
import org.emftext.language.java.members.Member;
import org.emftext.language.java.members.Method;
import org.emftext.language.java.members.impl.FieldImpl;
import org.emftext.language.java.modifiers.AnnotableAndModifiable;
import org.emftext.language.java.modifiers.AnnotationInstanceOrModifier;
import org.emftext.language.java.modifiers.Modifier;
import org.emftext.language.java.operators.GreaterThan;
import org.emftext.language.java.operators.GreaterThanOrEqual;
import org.emftext.language.java.operators.LessThan;
import org.emftext.language.java.operators.LessThanOrEqual;
import org.emftext.language.java.operators.impl.EqualImpl;
import org.emftext.language.java.operators.impl.NotEqualImpl;
import org.emftext.language.java.parameters.Parameter;
import org.emftext.language.java.references.IdentifierReference;
import org.emftext.language.java.references.MethodCall;
import org.emftext.language.java.references.StringReference;
import org.emftext.language.java.references.impl.IdentifierReferenceImpl;
import org.emftext.language.java.references.impl.MethodCallImpl;
import org.emftext.language.java.types.Type;
import org.emftext.language.java.types.TypeReference;
import org.emftext.language.java.variables.LocalVariable;
import org.emftext.language.java.variables.Variable;

/**
 * This class is used as a supporting library for writing rules for the rule
 * engine. It contains numerous methods to query a certain state of a java model
 * instance. For example, is a class is annotated with a specific annotation
 * name. Also the helper contains methods for retrieving aspects of a class like
 * the interfaces it is implementing.
 */
public class RuleHelper {

	public static boolean isAbstraction(CompilationUnitImpl unit) {
		for (final ConcreteClassifier classi : unit.getClassifiers()) {
			if (classi.eClass().getClassifierID() == ClassifiersPackage.INTERFACE) {
				return true;
			}
		}
		return false;
	}

	public static boolean isUnitAnnotatedWithName(CompilationUnitImpl unit, String... names) {
		for (final String name : names) {
			for (final ConcreteClassifier classi : unit.getClassifiers()) {
				if (isClassifierAnnotatedWithName(classi, name)) {
					return true;
				}
			}
		}
		return false;
	}

	public static boolean isObjectAnnotatedWithName(AnnotationInstanceOrModifier mod, String name) {
		if (mod.eClass().getClassifierID() == EcorePackage.EANNOTATION) {
			final AnnotationInstance anno = (AnnotationInstance) mod;

			if ((anno == null) || (anno.getAnnotation() == null)) {
				System.out.println("annotation was null, returning false");
				return false;
			}

			final String annoName = anno.getAnnotation().getName();
			if (annoName.equals(name)) {
				return true;
			}
		}
		return false;
	}

	public static boolean isClassifierAnnotatedWithName(Classifier classifier, String name) {
		if (classifier instanceof ConcreteClassifier) {
			final ConcreteClassifier classi = (ConcreteClassifier) classifier;
			for (final AnnotationInstanceOrModifier mod : classi.getAnnotationsAndModifiers()) {
				return isObjectAnnotatedWithName(mod, name);
			}
		}
		return false;
	}

	public static List<Method> getMethods(CompilationUnitImpl unit) {
		final List<Method> methods = new ArrayList<>();

		for (final ConcreteClassifier classi : unit.getClassifiers()) {
			for (final Member member : classi.getMembers()) {

				if (member instanceof Method) {
					final Method method = (Method) member;
					methods.add(method);
				}
			}
		}
		return methods;
	}

	public static List<Method> getMethods(Interface inter) {
		final List<Method> methods = new ArrayList<>();

		for (final Member member : inter.getMembers()) {

			if (member instanceof Method) {
				final Method method = (Method) member;
				methods.add(method);
			}
		}

		return methods;
	}

	public static List<Field> getFields(CompilationUnitImpl unit) {
		final List<Field> fields = new ArrayList<>();

		for (final ConcreteClassifier classi : unit.getClassifiers()) {
			for (final Member member : classi.getMembers()) {

				if (member.eClass().getName().equals("Field")) {
					final Field field = (Field) member;
					fields.add(field);
				}
			}
		}

		return fields;
	}

	public static boolean isMethodAnnotatedWithName(Method member, String... names) {
		for (final String name : names) {
			for (final AnnotationInstance a : member.getAnnotationInstances()) {
				if (a.getAnnotation().getName().equals(name)) {
					return true;
				}
			}
		}
		return false;
	}

	public static boolean isFieldAbstract(Field field) {
		if (field.getTypeReference() == null) {
			System.out.println("field: " + field.getName() + ", has type reference null");
			System.out.println("=> returning false for isFieldAbstract");
			return false;
		}
		final Type ref = field.getTypeReference().getTarget();

		if (ref instanceof Interface) {
			return true;
		}
		return false;
	}

	public static boolean isParameterAbstract(Parameter p) {
		if (p.getTypeReference().getTarget() instanceof Interface) {
			return true;
		}
		return false;
	}

	public static boolean isParameterAClassAnnotatedWith(Parameter para, String... names) {
		for (final String name : names) {
			final Classifier classi = para.getTypeReference().getPureClassifierReference().getTarget();
			if (isClassifierAnnotatedWithName(classi, name)) {
				return true;
			}
		}
		return false;
	}

	public static boolean isFieldModifiedExactlyWith(Field field, String... names) {
		return isObjectModifiedExactlyWith(field, names);
	}

	private static boolean isObjectModifiedExactlyWith(AnnotableAndModifiable modi, String... names) {
		final int numberOfModsToDetect = names.length;
		int detectionCounter = 0;
		for (final Modifier m : modi.getModifiers()) {
			final String modifierName = m.getClass().getSimpleName().toLowerCase();
			for (final String name : names) {
				if (modifierName.contains(name.toLowerCase())) {
					detectionCounter++;
				}
			}
		}
		if (detectionCounter == numberOfModsToDetect) {
			return true;
		}
		return false;
	}

	public static boolean isParameterAnnotatedWith(Parameter p, String name) {
		for (final AnnotationInstanceOrModifier a : p.getAnnotationsAndModifiers()) {
			if (isObjectAnnotatedWithName(a, name)) {
				return true;
			}
		}
		return false;
	}

	public static boolean isUnitNamedWith(CompilationUnitImpl unit, String name) {
		if ((unit != null) && (unit.getName() != null)) {
			if (unit.getName().contains(name)) {
				return true;
			}
		}
		return false;
	}

	public static boolean isUnitAnEnum(CompilationUnitImpl unit) {
		final Classifier classi = unit.getClassifiers().get(0);
		if (classi instanceof Enumeration) {
			return true;
		}
		return false;
	}

	public static List<Interface> getAllInterfaces(CompilationUnitImpl unit) {
		final List<Interface> interfaces = new ArrayList<>();
		if (unit.getName().contains("LocalDateAttr")) {
			final Class blubi = (Class) unit.getClassifiers().get(0);
			blubi.getImplements().forEach(im -> System.out
					.println("imp: " + im + ", target: " + im.getPureClassifierReference().getTarget()));
		}
		for (final ConcreteClassifier classifier : unit.getClassifiers()) {
			if (classifier instanceof Class) {
				final Class cl = (Class) classifier;
				final EList<TypeReference> references = cl.getImplements();

				if (references.size() > 0) {
					for (final TypeReference ref : references) {
						final Classifier innerClassi = ref.getPureClassifierReference().getTarget();
						if (innerClassi instanceof Interface) {
							interfaces.add((Interface) innerClassi);
						}
					}
				}
			}
		}
		return interfaces;
	}

	public static boolean isFieldAnnotatedWithName(Field field, String name) {
		for (final AnnotationInstance anno : field.getAnnotationInstances()) {
			if (anno.getAnnotation().getName().equals(name)) {
				return true;
			}
		}
		return false;
	}

	public static boolean isClassImplementing(CompilationUnitImpl unit) {

		for (final ConcreteClassifier classifier : unit.getClassifiers()) {
			if (classifier instanceof Class) {
				final Class cl = (Class) classifier;
				final EList<TypeReference> references = cl.getImplements();
				if (references.size() > 0) {
					return true;
				}
			}
		}
		return false;
	}

	public static boolean isClassExtending(CompilationUnitImpl unit) {
		for (final ConcreteClassifier classifier : unit.getClassifiers()) {
			if (classifier instanceof Class) {
				final Class cl = (Class) classifier;
				final TypeReference reference = cl.getExtends();
				if (reference != null) {
					return true;
				}
			}
		}
		return false;
	}

	public static Classifier getExtends(CompilationUnitImpl unit) {
		if (!isClassExtending(unit)) {
			return null;
		}
		final Classifier classi = unit.getClassifiers().get(0);
		if (classi instanceof Class) {
			final Class cl = (Class) classi;
			final TypeReference reference = cl.getExtends();
			return reference.getPureClassifierReference().getTarget();
		}
		return null;
	}

	public static boolean isClassModifiedExactlyWith(CompilationUnitImpl unit, String... names) {
		for (final ConcreteClassifier classi : unit.getClassifiers()) {
			if (classi instanceof Class) {
				return isObjectModifiedExactlyWith(classi, names);
			}
		}
		return false;
	}

	public static boolean isMethodModifiedExactlyWith(Method m, String... names) {
		return isObjectModifiedExactlyWith(m, names);
	}

	public static List<Method> getAllPublicMethods(CompilationUnitImpl unit) {
		return getMethods(unit).stream().filter(Method::isPublic).collect(Collectors.toList());
	}

	public static List<Constructor> getConstructors(CompilationUnitImpl unit) {
		final List<Constructor> constructors = new ArrayList<>();
		for (final ConcreteClassifier classi : unit.getClassifiers()) {
			for (final Member member : classi.getMembers()) {
				if (member instanceof Constructor) {
					constructors.add((Constructor) member);
				}
			}
		}
		return constructors;
	}

	public static boolean isConstructorAnnotatedWithName(Member member, String name) {
		if (member instanceof Constructor) {
			final Constructor c = (Constructor) member;
			for (final AnnotationInstance anno : c.getAnnotationInstances()) {
				if (anno.getAnnotation().getName().equals(name)) {
					return true;
				}
			}
		}
		return false;
	}

	public static boolean isClassOfFieldAnnotatedWithName(Variable v, String... names) {
		if (v == null || v.getTypeReference() == null || v.getTypeReference().getPureClassifierReference() == null) {
			return false;
		}
		Classifier currentClassifier = v.getTypeReference().getPureClassifierReference().getTarget();
		for (String name : names) {
			if (isClassifierAnnotatedWithName(currentClassifier, name)) {
				return true;
			}
		}
		return false;
	}

	/**
	 * Gets the name of the class of the callee of the given method call
	 * 
	 * @param methodCall the call from which the name of the class of the callee
	 *                   will be exrtracted
	 * @return the name of the callee
	 */
	public static String getTypeOfCallee(MethodCall methodCall) {
		if (methodCall.eContainer() instanceof IdentifierReferenceImpl
				&& ((IdentifierReferenceImpl) methodCall.eContainer()).getReferencedType() instanceof ClassImpl) {
			return ((ClassImpl) ((IdentifierReferenceImpl) methodCall.eContainer()).getReferencedType()).getName();
		}
		return null;

	}

	/**
	 * Gets a list of all method class inside a method
	 * 
	 * @param method the method from which the calls will be extracted
	 * @return list of the method calls found in the given method
	 */
	public static List<MethodCallImpl> getListOfCallsInMethod(Method method) {
		return method.getChildrenByType(MethodCallImpl.class);
	}

	/**
	 * Gets the Method from call to this Method. if the method is not found in the
	 * unit null is returned
	 * 
	 * @param unit the compilation unit of the method
	 * @param call call of the method
	 * @return the method
	 */
	public static Method getMethodWithNameFromUnit(CompilationUnitImpl unit, MethodCall call) {
		String name = getNameOfMethodCall(call);
		List<Method> methods = getMethods(unit);
		for (Method method : methods) {
			if (method.getName().equals(name)) {
				return method;
			}
		}
		return null;
	}

	/**
	 * Gets the method name by the call of the method
	 * 
	 * @param call the method call
	 * @return the name of the called method
	 */
	public static String getNameOfMethodCall(MethodCall call) {
		return ((Member) call.eCrossReferences().get(0)).getName();
	}

	/**
	 * Gets the annotation of an annotable object that has the same name as the
	 * given name. if there is no annotation with the given name null is returned
	 * 
	 * @param annotable        the object from which the annotation will be
	 *                         extracted
	 * @param nameOfAnnotation the name of the annotation, that has to be found
	 * @return the annotation or null
	 */
	public static AnnotationInstance getAnnotationOfAnnotableWithName(AnnotableAndModifiable annotable,
			String nameOfAnnotation) {

		for (AnnotationInstance annotation : annotable.getAnnotationInstances()) {
			if (annotation.getAnnotation().getName().equals(nameOfAnnotation)) {
				return annotation;
			}
		}

		return null;
	}

	/**
	 * Gets the value of the attribute of a given annotation that has the same name
	 * as the searched name. the value will be returned as string. if the attribute
	 * is not found null is returned
	 * 
	 * @param anno            the annotation from which the attribute has to
	 *                        extracted
	 * @param nameOfAttribute the name of the searched attribute
	 * @return the value of the attribute or null
	 */
	public static String getValueOfAttributeOfAnnotation(AnnotationInstance anno, String nameOfAttribute) {
		List<EObject> contents = anno.getParameter().eContents();
		for (EObject obj : contents) {
			if (obj instanceof AnnotationAttributeSetting) {
				AnnotationValue attr = ((AnnotationAttributeSetting) obj).getValue();
				String attributeName = ((AnnotationAttributeSetting) (obj)).getAttribute().getName();
				if (attributeName.equals(nameOfAttribute)) {
					String value = getValueOfDirectStringOrIdentifier(
							(CompilationUnitImpl) anno.getContainingCompilationUnit(), attr, null);
					return value;
				}
			}
		}
		return null;
	}

	/**
	 * Gets the value of direct string, string local variable or string Attribute .
	 * if it is local variable or attribute, the name of it has to match the one of
	 * the names provided
	 * 
	 * @param unit                            the compilation unit in which the
	 *                                        object is found
	 * @param obj                             the object that contains the string
	 * @param possibleNamesforSearchedElement list of the possible names if it is
	 *                                        attribute or local variable
	 * 
	 * @return the value of the given object
	 */
	public static String getValueOfDirectStringOrIdentifier(CompilationUnitImpl unit, EObject obj,
			String possibleNamesforSearchedElement[]) {
		// iff it is direct string
		if (obj instanceof StringReference) {
			return ((StringReference) obj).getValue();

			// iff value is written as Attribute or local variable
		} else if (obj instanceof Field || obj instanceof LocalVariable) {
			return getStringValueOfLocalVariableOrField(unit, obj, possibleNamesforSearchedElement);
			// iff value is written like (nameOfClass.getSomething().field) or something like that
		} else if (obj instanceof IdentifierReference ) {
			while(!obj.eContents().isEmpty()) {
				obj = obj.eContents().get(0);
			}
		
			obj =obj.eCrossReferences().get(0);
			String nameOfVariable = ((NamedElement) obj).getName();
			if (possibleNamesforSearchedElement == null) {
				possibleNamesforSearchedElement = new String[] { nameOfVariable };
			}
			if(obj instanceof FieldImpl ) {
				String value = getStringValueOfField((CompilationUnitImpl)((FieldImpl)obj).getContainingCompilationUnit(),
						(FieldImpl)obj, possibleNamesforSearchedElement);
				return value;
			
			}
			if(obj instanceof LocalVariable ) {
				return getStringValueOfLocalVariable( (LocalVariable)obj, possibleNamesforSearchedElement);
			}
		}
		
		return null;
	}

	/**
	 * Gets the string representation of the given condition
	 * 
	 * @param vollCondition the condition, of which a string representation has to
	 *                      be produced
	 * @return the condition as string
	 */
	public static String getVollConditionAsString(Expression vollCondition) {
		String output = "";
		// iff condition contains and
		if (vollCondition instanceof ConditionalAndExpressionImpl) {
			for (EObject internCondition : vollCondition.eContents()) {
				output += getVollConditionAsString(((Expression) internCondition)) + " &&";
			}
			output = output.substring(0, output.length() - 2);
			// iff condition contains or
		} else if (vollCondition instanceof ConditionalOrExpressionImpl) {
			for (EObject internCondition : vollCondition.eContents()) {
				output += getVollConditionAsString(((Expression) internCondition)) + " ||";
			}
			output = output.substring(0, output.length() - 2);
			// iff condition is true or false
		} else if (vollCondition instanceof BooleanLiteral) {
			output += getValueOfLiterals((Literal) vollCondition);
			// iff condition is nested
		} else if (vollCondition instanceof NestedExpression) {
			output += "(";
			for (EObject internCondition : vollCondition.eContents()) {

				output += getVollConditionAsString(((Expression) internCondition));
			}
			output += ")";
			// otherwise
		} else {

			output += getConditionAsString((Expression) vollCondition);
		}

		return output;
	}

	/**
	 * Gets the string representation of the given condition
	 * 
	 * @param condition the condition, of which a string representation has to be
	 *                  produced
	 * @return the condition as string
	 */
	public static String getConditionAsString(Expression condition) {
		String output = "";
		// if condition is method call
		if (condition instanceof IdentifierReference && !condition.getChildrenByType(MethodCall.class).isEmpty()) {
			output += ((NamedElement) condition.eCrossReferences().get(0)).getName() + handleLinkedCalls(condition);
			return output;
		}

		for (EObject obj : condition.eContents()) {
			// iff condition is local variable or attribute
			if (obj instanceof IdentifierReference && !obj.eCrossReferences().isEmpty()
					&& obj.eCrossReferences().get(0) instanceof NamedElement) {

				output += ((NamedElement) obj.eCrossReferences().get(0)).getName()
						+ handleLinkedCalls((IdentifierReference) obj) + ",";
				// iff condition is true or false
			} else if (obj instanceof Literal) {
				output += getValueOfLiterals((Literal) obj) + ",";
			}
		}

		output = getConditionOp(condition, output);

		return output;
	}

	/**
	 * adds the operation of the given condition to the given string and return the
	 * new string
	 * 
	 * @param condition the condition from which the operation will be extracted
	 * @param output    the condition as string
	 * @return the output after adding the operation
	 */
	private static String getConditionOp(Expression condition, String output) {

		String splittedString[] = output.split(",");

		if (!condition.eContents().isEmpty() && condition.eContents().get(0) instanceof EqualImpl) {
			output = "";
			for (String subString : splittedString) {
				output += subString + "==";
			}
			output = output.substring(0, output.length() - 2);

		}  else if(!condition.eContents().isEmpty() && condition.eContents().get(0) instanceof NotEqualImpl) {
			output = "";
			for (String subString : splittedString) {
				output += subString + "!=";
			}
			output = output.substring(0, output.length() - 2);


		} else if (condition.eContents().size() > 2 && condition.eContents().get(2) instanceof LessThan) {

			output = "";
			for (String subString : splittedString) {
				output += subString + "<";
			}
			output = output.substring(0, output.length() - 1);

		} else if (condition.eContents().size() > 2 && condition.eContents().get(2) instanceof GreaterThan) {

			output = "";
			for (String subString : splittedString) {
				output += subString + ">";
			}
			output = output.substring(0, output.length() - 1);
		} else if (condition.eContents().size() > 2 && condition.eContents().get(2) instanceof LessThanOrEqual) {

			output = "";
			for (String subString : splittedString) {
				output += subString + "<=";
			}
			output = output.substring(0, output.length() - 2);
		} else if (condition.eContents().size() > 2 && condition.eContents().get(2) instanceof GreaterThanOrEqual) {
			output = "";
			for (String subString : splittedString) {
				output += subString + ">=";
			}
			output = output.substring(0, output.length() - 2);

		} else {
			for (String subString : splittedString) {
				output += subString;
			}
		}
		return output;
	}

	/**
	 * Gets the value of the given literal as string
	 * 
	 * @param obj the literal, whose value has to be returned as string
	 * @return the value of the literal as string
	 */
	private static String getValueOfLiterals(Literal obj) {
		String output = "";
		if (obj instanceof BooleanLiteral) {
			output += ((BooleanLiteral) obj).isValue();
		} else if (obj instanceof CharacterLiteral) {
			output += ((CharacterLiteral) obj).getValue();
		} else if (obj instanceof DoubleLiteral) {
			output += ((DecimalDoubleLiteral) obj).getDecimalValue();
		} else if (obj instanceof FloatLiteral) {
			output += ((DecimalFloatLiteral) obj).getDecimalValue();
		} else if (obj instanceof DecimalIntegerLiteralImpl) {
			output += ((DecimalIntegerLiteralImpl) obj).getDecimalValue();
		} else if (obj instanceof LongLiteral) {
			output += ((DecimalLongLiteralImpl) obj).getDecimalValue();
		} else if (obj instanceof NullLiteral) {
			output += "null";
		}
		return output;
	}

	/**
	 * Gets the value of an identifier which is a string local variable or string
	 * attribute. the identifier has to match one of the accepted names, which will
	 * be provided by a list. the value of the first match will be returned
	 * 
	 * @param unit                             the unit that contains the identifier
	 * @param exp                              the expression, from which the value
	 *                                         will be extracted
	 * @param possibleNamesForSearchedVariable the list of the accepted names
	 * @return the value of the identifier
	 */
	public static String getStringValueOfIdentifier(CompilationUnitImpl unit, Expression exp,
			String possibleNamesForSearchedVariable[]) {
		List<EObject> list = exp.eCrossReferences();
		for (EObject obj : list) {

			String value = getStringValueOfLocalVariableOrField(unit, obj, possibleNamesForSearchedVariable);
			if (value != null) {
				return value;
			}
		}
		return null;
	}

	/**
	 * Gets the value of a string local variable or string attribute. variable has
	 * to match one of the accepted names, which will be provided by a list
	 * 
	 * @param unit                             the unit that contains the variable
	 * @param exp                              the expression, from which the value
	 *                                         will be extracted
	 * @param possibleNamesForSearchedVariable the list of the accepted names
	 * @return the value of the variable
	 */
	private static String getStringValueOfLocalVariableOrField(CompilationUnitImpl unit, EObject obj,
			String possibleNamesForSearchedVariable[]) {
		// get value of string local variable
		if (obj instanceof LocalVariable) {
			String value = getStringValueOfLocalVariable((LocalVariable) obj, possibleNamesForSearchedVariable);

			if (value != null) {
				return value;
			}
		}
		// get value of string attribute
		else if (obj instanceof FieldImpl) {

			String value = getStringValueOfField(unit, (FieldImpl) obj, possibleNamesForSearchedVariable);

			if (value != null) {
				return value;
			}

		}
		return null;
	}

	/**
	 * Gets the value of a string attribute. attribute has to match one of the
	 * accepted names, which will be provided by a list
	 * 
	 * @param unit                             the unit that contains the attribute
	 * @param exp                              the expression, from which the value
	 *                                         will be extracted
	 * @param possibleNamesForSearchedVariable the list of the accepted names
	 * @return the value of the attribute
	 */
	private static String getStringValueOfField(CompilationUnitImpl unit, FieldImpl obj,
			String[] possibleNamesForSearchedVariable) {
		EObject initialValue = obj.getInitialValue();

		// after and has to be the name
		for (int i = 0; i < possibleNamesForSearchedVariable.length; i++) {
			if (((FieldImpl) obj).getName().contains(possibleNamesForSearchedVariable[i])) {
				if (initialValue == null) {

					String value = getStringValueOfFieldFromConstructor(unit, possibleNamesForSearchedVariable);

					if (value == null) {
						AnnotationInstance anno = RuleHelper.getAnnotationOfAnnotableWithName(obj, "Value");
						value = getValueOfNamelessParameterOfAnnotation(anno);

					}
					return value;

				} else if (initialValue instanceof StringReference) {
					return ((StringReference) initialValue).getValue();

				}
			}

		}
		return null;
	}

	/**
	 * Gets the value of a string local variable. local variable has to match one of
	 * the accepted names, which will be provided by a list
	 * 
	 * @param unit                             the unit that contains the local
	 *                                         variable
	 * @param exp                              the expression, from which the value
	 *                                         will be extracted
	 * @param possibleNamesForSearchedVariable the list of the accepted names
	 * @return the value of the local variable
	 */
	private static String getStringValueOfLocalVariable(LocalVariable obj, String possibleNamesForSearchedVariable[]) {
		EObject initalValue = obj.getInitialValue();
		for (int i = 0; i < possibleNamesForSearchedVariable.length; i++) {
			if (initalValue instanceof StringReference
					&& ((LocalVariable) obj).getName().contains(possibleNamesForSearchedVariable[i])) {
				return ((StringReference) initalValue).getValue();
			}
		}
		return null;
	}

	/**
	 * Gets the value of not initialized string attribute. attribute has to match
	 * one of the accepted names, which will be provided by a list. the value will
	 * be extracted from the constructor iff an "value" annotation is provided in
	 * the constructor.
	 * 
	 * @param unit                             the unit that contains the attribute
	 * 
	 * @param possibleNamesForSearchedVariable the list of the accepted names
	 * @return the value of the attribute
	 */
	private static String getStringValueOfFieldFromConstructor(CompilationUnitImpl unit,
			String possibleNamesForSearchedVariable[]) {

		List<Constructor> constructors = RuleHelper.getConstructors(unit);
		for (Constructor cons : constructors) {

			for (Parameter para : cons.getParameters()) {
				for (int i = 0; i < possibleNamesForSearchedVariable.length; i++) {

					if (para.getName().equals(possibleNamesForSearchedVariable[i])) {
						AnnotationInstance anno = RuleHelper.getAnnotationOfAnnotableWithName(para, "Value");

						String value = getValueOfNamelessParameterOfAnnotation(anno);
						if (value == null) {
							continue;
						}
						return value;

					}
				}
			}
		}

		return null;
	}

	/**
	 * Gets the value of nameless parameter of an Annotation as string
	 * 
	 * @param anno the annotation, form which the value will be extracted
	 * @return the value of the annotation
	 */
	public static String getValueOfNamelessParameterOfAnnotation(AnnotationInstance anno) {

		if (anno == null) {
			return null;
		}
		EObject obj = anno.getParameter().eContents().get(0);
		String value = RuleHelper.getValueOfDirectStringOrIdentifier(
				(CompilationUnitImpl) anno.getContainingCompilationUnit(), obj, null);
		return value;

	}

	/**
	 * Gets the method call as string with its parameters
	 * 
	 * @param call the call, for which a string representation has to be extracted
	 * @return the string representation of the call
	 */
	public static String getMethodCallAsString(MethodCall call) {
		String callString = RuleHelper.getNameOfMethodCall((MethodCall) call) + "( ";

		for (Expression exp : call.getArguments()) {
			callString += extractExpressionAsString(exp) + handleLinkedCalls(exp) + ",";
		}

		if (callString.endsWith(",")) {
			callString = callString.substring(0, callString.length() - 1);
		}
		callString += ")";
		return callString;
	}

	/**
	 * Gets the string representation of the given expression
	 * 
	 * @param exp the expression, of which the string representation will be
	 *            produced
	 * @return the string representation of the expression
	 */
	private static String extractExpressionAsString(Expression exp) {
		// iff it is local variable or attribute
		if (exp instanceof NamedElement) {
			return ((NamedElement) exp).getName();
			// iff it is method call
		} else if (exp instanceof MethodCall) {
			return getMethodCallAsString((MethodCall) exp);
			// iff it is reference to local variable or attribute
		} else if (!exp.eCrossReferences().isEmpty() && exp.eCrossReferences().get(0) instanceof NamedElement) {
			return ((NamedElement) exp.eCrossReferences().get(0)).getName();
			// iff it is direct string
		} else if (exp instanceof StringReference) {
			return "\"" + ((StringReference) exp).getValue() + "\"";
			// iff it is constructor call
		} else if (exp instanceof NewConstructorCall) {
			return getNewConstructorCallAsString((NewConstructorCall) exp);
		}
		return "";
	}

	/**
	 * Gets the string representation of constructor call
	 * 
	 * @param constructorCall the constructor call, od which the string
	 *                        representation will be preoduced
	 * @return the string representation of the constructor call
	 */
	private static String getNewConstructorCallAsString(NewConstructorCall constructorCall) {
		String constructorCallAsString = "new " + ((NamedElement) constructorCall.getType()).getName() + "( ";
		for (Expression exp : constructorCall.getArguments()) {
			constructorCallAsString += extractExpressionAsString(exp) + handleLinkedCalls(exp) + ",";
		}
		if (constructorCallAsString.endsWith(",")) {
			constructorCallAsString = constructorCallAsString.substring(0, constructorCallAsString.length() - 1);
		}
		constructorCallAsString += ")";
		return constructorCallAsString;
	}

	/**
	 * Gets the string representation of call series of methods like for example
	 * set(..).get().add()
	 * 
	 * @param exp the expression that contains the method call
	 * @return a string representation of call series of given expression
	 */
	private static String handleLinkedCalls(Expression exp) {
		String calls = "";
		for (EObject obj : exp.eContents()) {
			if (obj instanceof MethodCall) {
				calls += "." + getMethodCallAsString((MethodCall) obj) + handleLinkedCalls((MethodCall) obj);
			}
		}
		return calls;
	}

}