package org.palladiosimulator.somox.analyzer.rules.maven;

import java.nio.file.Path;
import java.util.HashSet;
import java.util.Set;
import org.emftext.language.java.containers.impl.CompilationUnitImpl;
import org.palladiosimulator.somox.analyzer.rules.blackboard.RuleEngineBlackboard;
import org.palladiosimulator.somox.analyzer.rules.engine.IRule;

@SuppressWarnings("all")
public class MavenRules extends IRule {
  private static final String MAVEN_FILE_NAME = "pom.xml";

  public MavenRules(final RuleEngineBlackboard blackboard) {
    super(blackboard);
  }

  @Override
  public boolean processRules(final Path path) {
    if (((path != null) && path.getFileName().toString().equals(MavenRules.MAVEN_FILE_NAME))) {
      HashSet<CompilationUnitImpl> children = new HashSet<CompilationUnitImpl>();
      Path parentPath = path.getParent();
      Set<CompilationUnitImpl> _compilationUnits = this.blackboard.getCompilationUnits();
      for (final CompilationUnitImpl compUnit : _compilationUnits) {
        {
          boolean isChild = false;
          Set<Path> _compilationUnitLocations = this.blackboard.getCompilationUnitLocations(compUnit);
          for (final Path compUnitPath : _compilationUnitLocations) {
            boolean _startsWith = compUnitPath.startsWith(parentPath);
            if (_startsWith) {
              isChild = true;
            }
          }
          if (isChild) {
            children.add(compUnit);
          }
        }
      }
      this.blackboard.addSystemAssociations(path, children);
      return true;
    }
    return false;
  }
}
