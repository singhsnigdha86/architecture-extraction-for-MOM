package org.palladiosimulator.somox.analyzer.rules.mom;

import java.nio.file.Path;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import org.eclipse.xtext.xbase.lib.CollectionLiterals;
import org.eclipse.xtext.xbase.lib.Conversions;
import org.emftext.language.java.classifiers.Classifier;
import org.emftext.language.java.classifiers.impl.ClassImpl;
import org.emftext.language.java.containers.CompilationUnit;
import org.emftext.language.java.containers.impl.CompilationUnitImpl;
import org.emftext.language.java.members.Method;
import org.emftext.language.java.references.MethodCall;
import org.emftext.language.java.references.impl.MethodCallImpl;
import org.emftext.language.java.types.Type;
import org.palladiosimulator.somox.analyzer.rules.blackboard.RuleEngineBlackboard;
import org.palladiosimulator.somox.analyzer.rules.engine.IRule;
import org.palladiosimulator.somox.analyzer.rules.engine.PCMDetectorMom;
import org.palladiosimulator.somox.analyzer.rules.engine.PCMDetectorSimple;
import org.palladiosimulator.somox.analyzer.rules.engine.RuleHelper;

@SuppressWarnings("all")
public class MomRuleXtend extends IRule {
  /**
   * The annotation for the listeners
   */
  private Map<String, List<String>> annotations;

  /**
   * the class of the object, that sends the messages
   */
  private Map<String, List<String>> senderObjektTypes;

  /**
   * the methods of the objects, that are responsible for sending the messages
   */
  private Map<String, List<String>> sendMethods;

  /**
   * Help variable for the dfs
   */
  private boolean isChildSender;

  /**
   * the method call that sends the messages. for example method calls other method which calling send method of the technology. the other method will be saved here
   */
  private MethodCall originalSendCall;

  public MomRuleXtend(final RuleEngineBlackboard blackboard) {
    super(blackboard);
    HashMap<String, List<String>> _hashMap = new HashMap<String, List<String>>();
    this.annotations = _hashMap;
    HashMap<String, List<String>> _hashMap_1 = new HashMap<String, List<String>>();
    this.sendMethods = _hashMap_1;
    HashMap<String, List<String>> _hashMap_2 = new HashMap<String, List<String>>();
    this.senderObjektTypes = _hashMap_2;
    this.isChildSender = false;
    this.init();
  }

  /**
   * initializes the supported technologies. The initialization includes the the initialization of annotation, object class and the supported methods
   */
  public void init() {
    this.initAnnotations();
    this.initSenderObjekts();
    this.initSendMethods();
  }

  /**
   * initializes the annotation of the listener for the technology
   */
  public void initAnnotations() {
    final String[] annotationForKafke = ((String[])Conversions.unwrapArray(Collections.<String>unmodifiableSet(CollectionLiterals.<String>newHashSet("KafkaListener")), String.class));
    this.annotations.put("Kafka", Arrays.<String>asList(annotationForKafke));
    final String[] annotationForRabbitMQ = ((String[])Conversions.unwrapArray(Collections.<String>unmodifiableSet(CollectionLiterals.<String>newHashSet("RabbitListener")), String.class));
    this.annotations.put("RabbitMQ", Arrays.<String>asList(annotationForRabbitMQ));
    final String[] annotationForActiveMQ = ((String[])Conversions.unwrapArray(Collections.<String>unmodifiableSet(CollectionLiterals.<String>newHashSet("JmsListener")), String.class));
    this.annotations.put("ActiveMQ", Arrays.<String>asList(annotationForActiveMQ));
    final String[] annotationForRocketMQ = ((String[])Conversions.unwrapArray(Collections.<String>unmodifiableSet(CollectionLiterals.<String>newHashSet("RocketMQMessageListener")), String.class));
    this.annotations.put("RocketMQ", Arrays.<String>asList(annotationForRocketMQ));
    final String[] annotationForStreamListener = ((String[])Conversions.unwrapArray(Collections.<String>unmodifiableSet(CollectionLiterals.<String>newHashSet("StreamListener")), String.class));
    this.annotations.put("Stream", Arrays.<String>asList(annotationForStreamListener));
  }

  /**
   * initializes the object class, that are responsible for sending the messages.
   * each technology defines its own class for sending the messages
   */
  public void initSenderObjekts() {
    final String[] senderObjektsForKafke = ((String[])Conversions.unwrapArray(Collections.<String>unmodifiableSet(CollectionLiterals.<String>newHashSet("KafkaTemplate")), String.class));
    this.senderObjektTypes.put("Kafka", Arrays.<String>asList(senderObjektsForKafke));
    final String[] senderObjektsForRabbitMQ = ((String[])Conversions.unwrapArray(Collections.<String>unmodifiableSet(CollectionLiterals.<String>newHashSet("RabbitTemplate")), String.class));
    this.senderObjektTypes.put("RabbitMQ", Arrays.<String>asList(senderObjektsForRabbitMQ));
    final String[] senderObjektsForActiveMQ = ((String[])Conversions.unwrapArray(Collections.<String>unmodifiableSet(CollectionLiterals.<String>newHashSet("JmsTemplate")), String.class));
    this.senderObjektTypes.put("ActiveMQ", Arrays.<String>asList(senderObjektsForActiveMQ));
    final String[] senderObjektsForRocketMQ = ((String[])Conversions.unwrapArray(Collections.<String>unmodifiableSet(CollectionLiterals.<String>newHashSet("RocketMQTemplate")), String.class));
    this.senderObjektTypes.put("RocketMQ", Arrays.<String>asList(senderObjektsForRocketMQ));
    final String[] senderObjektsForStreamListener = ((String[])Conversions.unwrapArray(Collections.<String>unmodifiableSet(CollectionLiterals.<String>newHashSet("MessageChannel")), String.class));
    this.senderObjektTypes.put("Stream", Arrays.<String>asList(senderObjektsForStreamListener));
  }

  /**
   * initializes the methods, that send the messages to the topic.
   * each object defines at least one method for sending the messages
   */
  public void initSendMethods() {
    final String[] sendMethodsForKafkaTemplate = ((String[])Conversions.unwrapArray(Collections.<String>unmodifiableSet(CollectionLiterals.<String>newHashSet("send")), String.class));
    this.sendMethods.put("KafkaTemplate", Arrays.<String>asList(sendMethodsForKafkaTemplate));
    final String[] sendMethodsForRabbitMQ = ((String[])Conversions.unwrapArray(Collections.<String>unmodifiableSet(CollectionLiterals.<String>newHashSet("convertAndSend")), String.class));
    this.sendMethods.put("RabbitTemplate", Arrays.<String>asList(sendMethodsForRabbitMQ));
    final String[] sendMethodsForActiveMQ = ((String[])Conversions.unwrapArray(Collections.<String>unmodifiableSet(CollectionLiterals.<String>newHashSet("convertAndSend")), String.class));
    this.sendMethods.put("JmsTemplate", Arrays.<String>asList(sendMethodsForActiveMQ));
    final String[] sendMethodsForRocketMQ = ((String[])Conversions.unwrapArray(Collections.<String>unmodifiableSet(CollectionLiterals.<String>newHashSet("send")), String.class));
    this.sendMethods.put("RocketMQTemplate", Arrays.<String>asList(sendMethodsForRocketMQ));
    final String[] senderMethodsForStreamListener = ((String[])Conversions.unwrapArray(Collections.<String>unmodifiableSet(CollectionLiterals.<String>newHashSet("send")), String.class));
    this.sendMethods.put("MessageChannel", Arrays.<String>asList(senderMethodsForStreamListener));
  }

  @Override
  public boolean processRules(final Path path) {
    final Set<CompilationUnitImpl> unitImpls = this.blackboard.getCompilationUnitAt(path);
    boolean containedSuccessful = false;
    for (final CompilationUnitImpl unitImpl : unitImpls) {
      containedSuccessful = (this.processRules(unitImpl) || containedSuccessful);
    }
    return false;
  }

  public boolean processRules(final CompilationUnitImpl unitImpl) {
    final PCMDetectorSimple pcmDetector = this.blackboard.getPCMDetector();
    boolean _isUnitAnnotatedWithName = RuleHelper.isUnitAnnotatedWithName(unitImpl, "SpringBootApplication");
    if (_isUnitAnnotatedWithName) {
      ((PCMDetectorMom) pcmDetector).detectMicroservice(unitImpl);
    }
    boolean _isUnitAnnotatedWithName_1 = RuleHelper.isUnitAnnotatedWithName(unitImpl, "Component", "Service", "Controller", "RestController", 
      "RequestMapping", "ControllerAdvice");
    boolean _not = (!_isUnitAnnotatedWithName_1);
    if (_not) {
      return false;
    }
    pcmDetector.detectComponent(unitImpl);
    List<Method> _methods = RuleHelper.getMethods(unitImpl);
    for (final Method method : _methods) {
      Set<String> _keySet = this.annotations.keySet();
      for (final String technologie : _keySet) {
        List<String> _get = this.annotations.get(technologie);
        for (final String annotation : _get) {
          boolean _isMethodAnnotatedWithName = RuleHelper.isMethodAnnotatedWithName(method, annotation);
          if (_isMethodAnnotatedWithName) {
            ((PCMDetectorMom) pcmDetector).detectReceiver(unitImpl, method, annotation);
          }
        }
      }
    }
    List<Method> _methods_1 = RuleHelper.getMethods(unitImpl);
    for (final Method method_1 : _methods_1) {
      {
        List<MethodCallImpl> calls = RuleHelper.getListOfCallsInMethod(method_1);
        for (final MethodCall call : calls) {
          boolean _checkIfCallForSender = this.checkIfCallForSender(call);
          if (_checkIfCallForSender) {
            ((PCMDetectorMom) pcmDetector).detectSender(unitImpl, method_1, call, this.originalSendCall);
          } else {
            boolean senderCall = this.dfsForSender(call);
            if (senderCall) {
              ((PCMDetectorMom) pcmDetector).detectSender(unitImpl, method_1, call, this.originalSendCall);
              this.isChildSender = false;
              this.originalSendCall = null;
            }
          }
        }
      }
    }
    return false;
  }

  /**
   * searches in the given method call for a call of the send method
   */
  public boolean dfsForSender(final MethodCall call) {
    CompilationUnit _containingCompilationUnit = call.getReferencedType().getContainingCompilationUnit();
    CompilationUnitImpl unitImpl = ((CompilationUnitImpl) _containingCompilationUnit);
    boolean _checkStopConditionForDFS = this.checkStopConditionForDFS(call);
    if (_checkStopConditionForDFS) {
      return false;
    }
    Method method = RuleHelper.getMethodWithNameFromUnit(unitImpl, call);
    List<MethodCallImpl> calls = RuleHelper.getListOfCallsInMethod(method);
    for (final MethodCall methodCall : calls) {
      if ((this.checkIfCallForSender(methodCall) || this.isChildSender)) {
        this.isChildSender = true;
        return true;
      } else {
        boolean _checkStopConditionForDFS_1 = this.checkStopConditionForDFS(methodCall);
        boolean _not = (!_checkStopConditionForDFS_1);
        if (_not) {
          this.dfsForSender(methodCall);
        }
      }
    }
    return this.isChildSender;
  }

  /**
   * checks if the given call is a send call
   */
  public boolean checkIfCallForSender(final MethodCall call) {
    Set<String> _keySet = this.senderObjektTypes.keySet();
    for (final String technologie : _keySet) {
      List<String> _get = this.senderObjektTypes.get(technologie);
      for (final String sender : _get) {
        List<String> _get_1 = this.sendMethods.get(sender);
        for (final String sendMethod : _get_1) {
          {
            String methodName = RuleHelper.getNameOfMethodCall(call);
            if ((sender.equals(RuleHelper.getTypeOfCallee(call)) && sendMethod.equals(methodName))) {
              this.originalSendCall = call;
              return true;
            }
            Type _referencedType = call.getReferencedType();
            if ((_referencedType instanceof ClassImpl)) {
              Type _referencedType_1 = call.getReferencedType();
              boolean _equals = sender.equals(((ClassImpl) _referencedType_1).getName());
              if (_equals) {
                if ((((call.getNext() != null) && (call.getNext() instanceof MethodCallImpl)) && 
                  RuleHelper.getNameOfMethodCall(((MethodCallImpl) call.getNext())).equals(sendMethod))) {
                  this.originalSendCall = call;
                  return true;
                }
              }
            }
          }
        }
      }
    }
    return false;
  }

  /**
   * defines the stop condition for the depth first search (dfs) for the send call
   */
  public boolean checkStopConditionForDFS(final MethodCall call) {
    if (this.isChildSender) {
      return true;
    }
    Type _referencedType = call.getReferencedType();
    if ((_referencedType instanceof Classifier)) {
      return true;
    }
    CompilationUnit _containingCompilationUnit = call.getReferencedType().getContainingCompilationUnit();
    CompilationUnitImpl unitOfTheCalledMethod = ((CompilationUnitImpl) _containingCompilationUnit);
    if (((!this.isChildSender) && "".equals(unitOfTheCalledMethod.getName()))) {
      return true;
    }
    Method externalMethod = RuleHelper.getMethodWithNameFromUnit(unitOfTheCalledMethod, call);
    if ((externalMethod == null)) {
      return true;
    }
    return false;
  }
}
