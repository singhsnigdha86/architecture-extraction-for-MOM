/**
 * This package provides the fluent API for the {@link org.palladiosimulator.pcm.system.System
 * System} model. See the factory for more details.
 *
 * @see org.palladiosimulator.generator.fluent.system.factory.FluentSystemFactory
 */
package org.palladiosimulator.generator.fluent.system;
