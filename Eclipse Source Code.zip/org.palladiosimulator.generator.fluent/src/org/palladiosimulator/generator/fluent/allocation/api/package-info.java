/**
 * This package contains the interfaces used to add entities to an
 * {@link org.palladiosimulator.pcm.allocation.Allocation Allocation} model.
 */
package org.palladiosimulator.generator.fluent.allocation.api;
