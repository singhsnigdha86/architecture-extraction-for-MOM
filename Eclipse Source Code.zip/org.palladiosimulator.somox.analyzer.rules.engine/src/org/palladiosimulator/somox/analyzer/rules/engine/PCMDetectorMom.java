package org.palladiosimulator.somox.analyzer.rules.engine;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import org.eclipse.emf.ecore.EObject;
import org.emftext.language.java.annotations.AnnotationInstance;
import org.emftext.language.java.containers.impl.CompilationUnitImpl;
import org.emftext.language.java.expressions.Expression;
import org.emftext.language.java.instantiations.NewConstructorCall;
import org.emftext.language.java.members.Method;
import org.emftext.language.java.modifiers.AnnotableAndModifiable;
import org.emftext.language.java.references.Argumentable;
import org.emftext.language.java.references.IdentifierReference;
import org.emftext.language.java.references.MethodCall;
import org.emftext.language.java.references.StringReference;

public class PCMDetectorMom extends PCMDetectorSimple {

	private Map<CompilationUnitImpl, List<MethodWithTopic>> receivers = new HashMap<>();
	private Map<CompilationUnitImpl, List<MethodWithTopic>> senders = new HashMap<>();
	private List<CompilationUnitImpl> microservices = new ArrayList<>();
	public final String NAMES_FOR_PLACEHOLDER_OF_TOPICS[] = { "topic", "topicName", "queue", "group", "queueName",
			"QUEUE" };
	public final String NAMES_OF_ATTRIBUTE_FOR_LISTENER[] = { "topics", "queues", "inputChannel", "destination",
			"topic", "inputChannel", "condition" };

	public final String ANNOTATION_FOR_SENDERS[] = { "Output" };

	/**
	 * Detects the given unit as receiver through the given method, which has the
	 * given annotation. the name of the topic, from which the unit receives, will
	 * be extracted.
	 * 
	 * the unit and the method together with the name of the topic will be added to
	 * the receivers map
	 * 
	 * @param unit            the new receiver
	 * @param method          the method that receives the messages from the topic
	 * @param foundAnnotation the found annotation
	 */
	public void detectReceiver(CompilationUnitImpl unit, Method method, String foundAnnotation) {

		String nameOfTheTopic = getNameOfTopicForReceiver(method, foundAnnotation);
		if (nameOfTheTopic == null) {
			nameOfTheTopic = "ALL";
		}
		final String finalNameOfTheTopic = proccessTheNameOfTopic(nameOfTheTopic);
		if (!receivers.keySet().contains(unit)) {
			receivers.put(unit, new ArrayList<MethodWithTopic>());
		}

		boolean isContained = receivers.get(unit).stream()
				.anyMatch(methodWithTopic -> methodWithTopic.getTopic().equals(finalNameOfTheTopic));
		if (!isContained) {
			receivers.get(unit).add(new MethodWithTopic(finalNameOfTheTopic, method, null));
		}
	}

	/**
	 * Detects the given unit as sender through the given method, which has the
	 * given send call. the name of the topic, to which the unit sends, will be
	 * extracted.
	 * 
	 * the unit and the method together with the name of the topic and the send call
	 * will be added to the senders map
	 * 
	 * @param unit   the new sender
	 * @param method the method that sends the messages to the topic
	 * @param call   the indirect send call
	 * @param originalSendCall the direct send call
	 */
	public void detectSender(CompilationUnitImpl unit, Method method, MethodCall call, MethodCall originalSendCall) {

		final String nameOfTheTopic = getNameofTopicForSender(unit, call, originalSendCall,
				NAMES_FOR_PLACEHOLDER_OF_TOPICS);
		if (nameOfTheTopic == null) {

			return;
		}
		if (!senders.keySet().contains(unit)) {
			senders.put(unit, new ArrayList<MethodWithTopic>());
		}

		senders.get(unit).add(new MethodWithTopic(nameOfTheTopic, method, call));

	}

	/**
	 * returns the map of the senders
	 * 
	 * @return the map of the senders
	 */
	public Map<CompilationUnitImpl, List<MethodWithTopic>> getSenders() {
		return senders;
	}

	/**
	 * returns the map of the senders
	 * 
	 * @return the map of the senders
	 */
	public Map<CompilationUnitImpl, List<MethodWithTopic>> getReceivers() {
		return receivers;
	}

	/**
	 * Gets the name of the topic, that a sender unit sends to through a given
	 * method call if is the name is value of variable .the variable has to match
	 * one of the given accepted names
	 * 
	 * @param unit                              the sender unit
	 * @param methodCall                        the indirect call that sends the messages
	 * @param originalSendCall                  the direct call that sends the messages
	 * @param nameForTopicVariablePerConvention the list of the accepted names of
	 *                                          the variables
	 * @return name of the topic
	 */
	private String getNameofTopicForSender(CompilationUnitImpl unit, Argumentable methodCall,
			MethodCall originalSendCall, String nameForTopicVariablePerConvention[]) {
		List<Expression> arguments = methodCall.getArguments();

		for (Expression exp : arguments) {
			// if first Argument in the send method call is constructor
			if (exp instanceof NewConstructorCall) {
				Argumentable constructor = ((NewConstructorCall) exp);
				return getNameofTopicForSender(unit, constructor, originalSendCall, nameForTopicVariablePerConvention);

				// get value of direct written string or a variable
			} else if (exp instanceof StringReference || exp instanceof IdentifierReference) {
				String value = RuleHelper.getValueOfDirectStringOrIdentifier(unit, exp,
						nameForTopicVariablePerConvention);
				if (value != null) {
					return value;
				}

			}

		}

		// get value of a constructor if it is not given to the send method
		if (!arguments.isEmpty() && arguments.get(0) instanceof IdentifierReference) {
			List<EObject> constructors = arguments.get(0).eCrossReferences().get(0).eContents().stream()
					.filter(content -> content instanceof NewConstructorCall).collect(Collectors.toList());
			if (constructors.isEmpty()) {
				return null;
			}
			NewConstructorCall constructor = (NewConstructorCall) constructors.get(0);

			String value = getNameofTopicForSender(unit, constructor, originalSendCall,
					nameForTopicVariablePerConvention);
			return value;
		}

		for (int i = 0; i < ANNOTATION_FOR_SENDERS.length; i++) {
			AnnotationInstance sendCallAnnotation = RuleHelper.getAnnotationOfAnnotableWithName(
					(AnnotableAndModifiable) methodCall.eCrossReferences().get(0), ANNOTATION_FOR_SENDERS[i]);
			
			AnnotationInstance originalSendCallAnnotation = RuleHelper.getAnnotationOfAnnotableWithName(
					(AnnotableAndModifiable) originalSendCall.eCrossReferences().get(0), ANNOTATION_FOR_SENDERS[i]);
			
			if (sendCallAnnotation != null) {
				String value = RuleHelper.getValueOfNamelessParameterOfAnnotation(sendCallAnnotation);
				return value;
			} else if ( originalSendCallAnnotation != null) {
				
				String value = RuleHelper.getValueOfNamelessParameterOfAnnotation(originalSendCallAnnotation);
				return value;
			}
		}

		return null;
	}

	/**
	 * Gets name of the topic for a receiver from an annotation of the given method.
	 * iff attribute of the annotation of the method that has the same name as the
	 * given name has one of the searched Attributes. the value of the attribute
	 * will be identified as the name of the topic and will be returned. otherwise
	 * null is returned
	 * 
	 * @param method           the method that receives the messages from the topic
	 *                         and has the searched annotation
	 * @param nameOfAnnotation the searched annotation
	 * @return the name of the topic
	 */
	private String getNameOfTopicForReceiver(Method method, String nameOfAnnotation) {
		if (RuleHelper.isMethodAnnotatedWithName(method, nameOfAnnotation)) {
			AnnotationInstance anno = RuleHelper.getAnnotationOfAnnotableWithName(method, nameOfAnnotation);
			for (int i = 0; i < NAMES_OF_ATTRIBUTE_FOR_LISTENER.length; i++) {
				String value = RuleHelper.getValueOfAttributeOfAnnotation(anno, NAMES_OF_ATTRIBUTE_FOR_LISTENER[i]);
				if (value != null) {
					return value;
				}
			}
		}

		//An Exception: StreamListener can have a parameter without name
		if (nameOfAnnotation.equals("StreamListener")) {
			AnnotationInstance annotation = RuleHelper.getAnnotationOfAnnotableWithName(method, nameOfAnnotation);
			String value = null;
			if (annotation != null) {
				value = RuleHelper.getValueOfNamelessParameterOfAnnotation(annotation);
			}

			return value;
		}
		return null;
	}

	/**
	 * processes the name of the topic by removing not wanted characters
	 * 
	 * @param nameOfTheTopic the name of the topic that should be processed
	 * @return the name of the topic after processing
	 */
	private String proccessTheNameOfTopic(String nameOfTheTopic) {
		String splittedName[] = null;
		if (nameOfTheTopic.contains("==")) {
			splittedName = nameOfTheTopic.split("==");
		} else {
			return nameOfTheTopic;
		}
		String splittedName2[] = null;
		if (splittedName != null) {
			splittedName2 = splittedName[1].split("'");
		}

		return splittedName2[1] != null ? splittedName2[1] : nameOfTheTopic;

	}

	/**
	 * Detects the given unit as a new microservice and adds it to the microservices
	 * list
	 * 
	 * @param unitImpl the unit that will be the new microservice
	 */
	public void detectMicroservice(CompilationUnitImpl unitImpl) {
		microservices.add(unitImpl);

	}

	/**
	 * Gets a list of all found microservices in the system
	 * 
	 * @return a list of all found microservices in the system
	 */
	public List<CompilationUnitImpl> getMicroservices() {
		return microservices;
	}

}
