package org.palladiosimulator.generator.fluent.system.api;

/**
 * TODO
 */
public interface ISystem extends ISystemAddition {

    /**
     * Defines the name of the org.palladiosimulator.generator.fluent.system.
     *
     * @param name
     * @return this org.palladiosimulator.generator.fluent.system
     */
    ISystem withName(String name);
}
