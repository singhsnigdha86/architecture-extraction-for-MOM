/**
 * This package contains the interfaces used to add entities to a
 * {@link org.palladiosimulator.pcm.resourceenvironment.ResourceEnvironment ResourceEnvironment}
 * model.
 */
package org.palladiosimulator.generator.fluent.resourceenvironment.api;
