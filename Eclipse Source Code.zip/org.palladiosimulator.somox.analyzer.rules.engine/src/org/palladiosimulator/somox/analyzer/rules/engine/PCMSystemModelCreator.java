package org.palladiosimulator.somox.analyzer.rules.engine;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.palladiosimulator.generator.fluent.system.api.ISystem;
import org.palladiosimulator.generator.fluent.system.factory.FluentSystemFactory;
import org.palladiosimulator.generator.fluent.system.structure.AssemblyContextCreator;
import org.palladiosimulator.generator.fluent.system.structure.EventChannelCreator;
import org.palladiosimulator.generator.fluent.system.structure.connector.event.EventChannelSinkConnectorCreator;
import org.palladiosimulator.generator.fluent.system.structure.connector.event.EventChannelSourceConnectorCreator;
import org.palladiosimulator.generator.fluent.system.structure.connector.operation.ProvidedDelegationConnectorCreator;
import org.palladiosimulator.generator.fluent.system.structure.role.OperationProvidedRoleCreator;
import org.palladiosimulator.pcm.repository.Repository;
import org.palladiosimulator.somox.analyzer.rules.blackboard.RuleEngineBlackboard;

/**
 * This class creates a pcm-system-model from the already created repository
 *
 */
public class PCMSystemModelCreator {
	private final static String System_NAME = "Software Architecture System";
	private final FluentSystemFactory create;
	private final ISystem system;
	private List<String> createdChannels;
	private Map<String, List<String>> sourceRoleConnectors;
	private Map<String, List<String>> createdSinkRoles;

	public PCMSystemModelCreator(Repository repository, RuleEngineBlackboard blackboard) {
		create = new FluentSystemFactory();
		system = create.newSystem().withName(System_NAME);
		system.addRepository(repository);
		createdChannels = new ArrayList<>();
		sourceRoleConnectors = new HashMap<>();
		createdSinkRoles = new HashMap<>();

	}

	/**
	 * Creates the pcm system model
	 * 
	 * @param microserviceSenders    the senders in the system together with sender
	 *                               relevant information
	 * @param microservicesReceivers the receivers in the system together with
	 *                               receiver relevant information
	 * @return the new created system model
	 */
	public org.palladiosimulator.pcm.system.System createPCMSystemModel(
			Map<String, List<MethodWithTopic>> microserviceSenders,
			Map<String, List<MethodWithTopic>> microservicesReceivers,
			Map<String, List<String>> microserviceToProvidedRoles) {

		Set<String> microservices = new HashSet<>();
		microservices.addAll(microserviceSenders.keySet());

		for (String microserviceName : microservicesReceivers.keySet()) {
			if (!microservices.contains(microserviceName)) {

				microservices.add(microserviceName);
			}
		}
		createAssemblyContexts(microservices);

		createEventChannels(microserviceSenders, microservicesReceivers);

		provideSystemCalls(microserviceToProvidedRoles);

		org.palladiosimulator.pcm.system.System systemModel = system.createSystemNow();
		return systemModel;
	}

	/**
	 * Creates the event channels for the system model
	 * 
	 * @param microserviceSenders   the senders in the system together with sender
	 *                              relevant information
	 * @param microserviceReceivers the receivers in the system together with
	 *                              receiver relevant information
	 */
	private void createEventChannels(Map<String, List<MethodWithTopic>> microserviceSenders,
			Map<String, List<MethodWithTopic>> microserviceReceivers) {

		for (String sender : microserviceSenders.keySet()) {

			List<MethodWithTopic> sendMethods = microserviceSenders.get(sender);
			for (MethodWithTopic sendMethodTopic : sendMethods) {
				connectReceiversToSender(microserviceReceivers, sendMethodTopic, sender);
			}
		}

	}

	/**
	 * Creates the event channel source connector for the sender
	 * 
	 * @param sender                the sender to the topic
	 * @param receiver              the receiver from the topic
	 * @param eventType             the event type
	 * @param senderMethodWithTopic sender relevant information
	 */
	private void addEventChannelSourceConnector(String sender, String receiver, String eventType,
			MethodWithTopic senderMethodWithTopic) {
		if (sourceRoleConnectors.containsKey(sender)
				&& sourceRoleConnectors.get(sender).contains(senderMethodWithTopic.getRole())) {
			return;
		}
		EventChannelSourceConnectorCreator sourceConnectorCreator = create.newEventChannelSourceConnector()
				.withName(senderMethodWithTopic.getRole());

		sourceConnectorCreator = sourceConnectorCreator.withAssemblyContext(sender)
				.withSourceRole(senderMethodWithTopic.getRole());
		sourceConnectorCreator = sourceConnectorCreator.withEventChannel(senderMethodWithTopic.getTopic());

		system.addToSystem(sourceConnectorCreator);
		if (!sourceRoleConnectors.containsKey(sender)) {
			sourceRoleConnectors.put(sender, new ArrayList<>());
		}
		sourceRoleConnectors.get(sender).add(senderMethodWithTopic.getRole());
	}

	/**
	 * Creates the event channel sink connector for the receiver
	 * 
	 * @param sender                the sender to the topic
	 * @param receiver              the receiver from the topic
	 * @param eventType             the event type
	 * @param senderMethodWithTopic sender relevant information
	 */
	private void addEventChannelSinkConnector(String sender, String receiver, String eventType,
			MethodWithTopic receiverMethodWithTopic) {
		if (createdSinkRoles.containsKey(receiver)
				&& createdSinkRoles.get(receiver).contains(receiverMethodWithTopic.getRole())) {
			return;
		}
		EventChannelSinkConnectorCreator sinkConnectorCreator = create.newEventChannelSinkConnector()
				.withName(receiverMethodWithTopic.getRole());

		sinkConnectorCreator.withAssemblyContext(receiver).withSinkRole(receiverMethodWithTopic.getRole());
		sinkConnectorCreator.withEventChannel(receiverMethodWithTopic.getTopic());

		system.addToSystem(sinkConnectorCreator);
		if (!createdSinkRoles.containsKey(receiver)) {
			createdSinkRoles.put(receiver, new ArrayList<>());
		}
		createdSinkRoles.get(receiver).add(receiverMethodWithTopic.getRole());
	}

	/**
	 * Creates the assembly contexts in the system
	 * 
	 * @param components the name of all components in the system
	 */
	private void createAssemblyContexts(Set<String> components) {
		for (String component : components) {

			AssemblyContextCreator assemblyCon = create.newAssemblyContext().withEncapsulatedComponent(component)
					.withName(component);
			system.addToSystem(assemblyCon);

		}

	}

	/**
	 * Connecting the source connector of a sender to an event channel and the sink
	 * connector of a receiver to the same event channel
	 * 
	 * @param microserviceReceivers the receivers in the system with receivers
	 *                              relevant informations
	 * @param sendMethodTopic       sender relevant informations
	 * @param sender                the name of the senders
	 */
	private void connectReceiversToSender(Map<String, List<MethodWithTopic>> microserviceReceivers,
			MethodWithTopic sendMethodTopic, String sender) {
		boolean sourceConnectorCreated = false;
		for (String receiver : microserviceReceivers.keySet()) {
			List<MethodWithTopic> receiveMethodTopics = microserviceReceivers.get(receiver);
			for (MethodWithTopic recMetTop : receiveMethodTopics) {

				if (!sendMethodTopic.getTopic().equals(recMetTop.getTopic())) {
					continue;
				}
				boolean channelIsCreated = createdChannels.stream()
						.anyMatch(topic -> topic.equals(sendMethodTopic.getTopic()));

				if (!channelIsCreated) {
					EventChannelCreator eventChannelCreator = create.newEventChannelCreator()
							.withName(sendMethodTopic.getTopic())
							.withEventGroup(sendMethodTopic.getTopic().replaceAll("\\.", "_"));
					system.addToSystem(eventChannelCreator);
					createdChannels.add(sendMethodTopic.getTopic());
				}

				addEventChannelSinkConnector(sender, receiver, recMetTop.getEventType(), recMetTop);
				addEventChannelSourceConnector(sender, receiver, sendMethodTopic.getEventType(), sendMethodTopic);
				sourceConnectorCreated = true;

			}
		}
		if (!sourceConnectorCreated) {
			boolean channelIsCreated = createdChannels.stream()
					.anyMatch(topic -> topic.equals(sendMethodTopic.getTopic()));

			if (!channelIsCreated) {
				EventChannelCreator eventChannelCreator = create.newEventChannelCreator()
						.withName(sendMethodTopic.getTopic())
						.withEventGroup(sendMethodTopic.getTopic().replaceAll("\\.", "_"));
				system.addToSystem(eventChannelCreator);
				createdChannels.add(sendMethodTopic.getTopic());
			}

			addEventChannelSourceConnector(sender, null, sendMethodTopic.getEventType(), sendMethodTopic);
		}
	}

	/**
	 * Creates provided Roles for the system and connect them with the provided role
	 * of the microservice
	 * 
	 * @param microserviceToRoles the mapping of the microservices to the provided
	 *                            roles
	 */
	private void provideSystemCalls(Map<String, List<String>> microserviceToRoles) {
		for (String microservice : microserviceToRoles.keySet()) {
			for (String providedRole : microserviceToRoles.get(microservice)) {
				OperationProvidedRoleCreator operationProvidedRole = create.newOperationProvidedRole()
						.withName(providedRole + "Of_System");
				operationProvidedRole
						.withProvidedInterface(PCMInstanceCreatorMoM.constructNameOfProvidedInterface(microservice));
				system.addToSystem(operationProvidedRole);
				String providedRoleName = PCMInstanceCreatorMoM.constructNameOfProvidedRole(microservice);
				ProvidedDelegationConnectorCreator providedDelegationConnectorCreator = create
						.newProvidedDelegationConnectorCreator().withOuterProvidedRole(providedRole + "Of_System")
						.withProvidingContext(microservice).withOperationProvidedRole(providedRoleName);// withOperationProvidedRole(providedRole);
				system.addToSystem(providedDelegationConnectorCreator);
			}

		}

	}

}
