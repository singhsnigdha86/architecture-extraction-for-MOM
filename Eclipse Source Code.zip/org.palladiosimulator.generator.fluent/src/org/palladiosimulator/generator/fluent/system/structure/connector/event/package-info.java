/**
 * This package contains the creators for connectors concerning events.
 */
package org.palladiosimulator.generator.fluent.system.structure.connector.event;
